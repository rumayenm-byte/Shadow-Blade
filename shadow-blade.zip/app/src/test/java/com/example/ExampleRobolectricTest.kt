package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ninja.engine.GameEngine
import com.example.ninja.engine.LevelBuilder
import com.example.ninja.model.PlayerState
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Shadow Blade", appName)
    }

    @Test
    fun testNinjaMovementLeftAndRight() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)
        val soundManager = SoundManager(context)
        soundManager.isSoundEnabled = false
        soundManager.isMusicEnabled = false

        val levelData = LevelBuilder.buildLevel(1)
        val engine = GameEngine(levelData, preferences, soundManager)

        // Drop ninja to ground and settle
        for (i in 0..20) {
            engine.update(0.016f)
        }
        assertTrue("Player should be grounded", engine.player.isGrounded)
        val startX = engine.player.x

        // Move Right
        engine.inputRight = true
        engine.inputLeft = false
        for (i in 0..10) {
            engine.update(0.016f)
        }
        assertTrue("Ninja should move right", engine.player.x > startX)
        assertTrue("Facing right should be true", engine.player.facingRight)

        // Move Left
        val rightX = engine.player.x
        engine.inputRight = false
        engine.inputLeft = true
        for (i in 0..10) {
            engine.update(0.016f)
        }
        assertTrue("Ninja should move left", engine.player.x < rightX)
        assertFalse("Facing right should be false", engine.player.facingRight)
    }

    @Test
    fun testNinjaJumpGravityAndLanding() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)
        val soundManager = SoundManager(context)
        soundManager.isSoundEnabled = false
        soundManager.isMusicEnabled = false

        val levelData = LevelBuilder.buildLevel(1)
        val engine = GameEngine(levelData, preferences, soundManager)

        // Settle on ground
        for (i in 0..20) {
            engine.update(0.016f)
        }
        val groundY = engine.player.y
        assertTrue("Player should be grounded", engine.player.isGrounded)

        // Press Jump
        engine.inputJumpPressed = true
        engine.update(0.016f)

        assertFalse("Player should not be grounded immediately after jump", engine.player.isGrounded)
        assertTrue("Player vertical velocity should be negative (upward)", engine.player.vy < 0f)
        assertTrue("Player should be in air", engine.player.y < groundY)

        // Simulate full jump arc with gravity and landing
        for (i in 0..70) {
            engine.update(0.016f)
        }

        // Should land back on the ground platform
        assertTrue("Player should land and be grounded", engine.player.isGrounded)
        assertEquals("Player should land at platform surface Y", groundY, engine.player.y, 1.0f)
        assertEquals("Player vertical velocity should be 0 when landed", 0f, engine.player.vy, 0.01f)
    }

    @Test
    fun testNinjaKatanaAttackAnimation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val preferences = GamePreferences(context)
        val soundManager = SoundManager(context)
        soundManager.isSoundEnabled = false
        soundManager.isMusicEnabled = false

        val levelData = LevelBuilder.buildLevel(1)
        val engine = GameEngine(levelData, preferences, soundManager)

        // Settle on ground
        for (i in 0..10) {
            engine.update(0.016f)
        }

        assertEquals(0f, engine.player.slashTimer, 0.001f)

        // Trigger attack
        engine.inputAttackPressed = true
        engine.update(0.016f)

        assertTrue("Slash timer should be active", engine.player.slashTimer > 0f)
        assertEquals("State should be SLASHING", PlayerState.SLASHING, engine.player.state)
    }
}
