package com.example.ninja.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun MainMenuScreen(
    preferences: GamePreferences,
    soundManager: SoundManager,
    onStartGame: (levelIndex: Int) -> Unit,
    onOpenLevelSelect: () -> Unit,
    onOpenDojo: () -> Unit
) {
    var soundEnabled by remember { mutableStateOf(preferences.isSoundEnabled) }
    var musicEnabled by remember { mutableStateOf(preferences.isMusicEnabled) }
    var hapticsEnabled by remember { mutableStateOf(preferences.isHapticsEnabled) }

    // Start background music if enabled
    LaunchedEffect(Unit) {
        if (preferences.isMusicEnabled) {
            soundManager.startMusic()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian)
    ) {
        // --- Animated Background Canvas ---
        var animTick by remember { mutableLongStateOf(0L) }
        LaunchedEffect(Unit) {
            while (true) {
                withFrameNanos { now ->
                    animTick = now
                }
            }
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val tick = animTick
            val t = System.currentTimeMillis() * 0.001f

            // Sky gradient
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF070B14), Color(0xFF141926), Color(0xFF260D12)),
                    startY = 0f,
                    endY = size.height
                ),
                topLeft = Offset.Zero,
                size = size
            )

            // Giant Blood Moon
            val moonCenterX = size.width * 0.72f
            val moonCenterY = size.height * 0.42f
            val moonRad = 85f
            drawCircle(
                color = Color(0x33FF1744),
                radius = moonRad + 28f,
                center = Offset(moonCenterX, moonCenterY)
            )
            drawCircle(
                color = Color(0xFFFF1744),
                radius = moonRad,
                center = Offset(moonCenterX, moonCenterY)
            )
            // Crescent shadow
            drawCircle(
                color = Color(0xFF070B14),
                radius = moonRad * 0.9f,
                center = Offset(moonCenterX - 8f, moonCenterY)
            )

            // Distant mountain ridge
            val mPath = Path().apply {
                moveTo(0f, size.height)
                lineTo(0f, size.height * 0.65f)
                lineTo(size.width * 0.25f, size.height * 0.52f)
                lineTo(size.width * 0.5f, size.height * 0.68f)
                lineTo(size.width * 0.75f, size.height * 0.48f)
                lineTo(size.width, size.height * 0.62f)
                lineTo(size.width, size.height)
                close()
            }
            drawPath(mPath, Color(0x55000000))

            // Foreground Pagoda Silhouette
            val pBaseY = size.height * 0.88f
            val pX = size.width * 0.82f
            drawRect(Color(0xFF090C12), topLeft = Offset(pX - 40f, pBaseY - 60f), size = Size(80f, 60f))
            val roof = Path().apply {
                moveTo(pX - 60f, pBaseY - 60f)
                lineTo(pX + 60f, pBaseY - 60f)
                lineTo(pX, pBaseY - 95f)
                close()
            }
            drawPath(roof, Color(0xFF090C12))

            // Ground silhouette
            drawRect(
                color = Color(0xFF090C12),
                topLeft = Offset(0f, size.height * 0.82f),
                size = Size(size.width, size.height * 0.18f)
            )

            // Bamboo stalks on left side
            for (i in 0..4) {
                val bx = 40f + i * 45f
                val sway = sin(t + i) * 6f
                drawLine(
                    color = Color(0xFF090C12),
                    start = Offset(bx, size.height),
                    end = Offset(bx + sway, size.height * 0.25f),
                    strokeWidth = 12f
                )
            }

            // Drifting sakura blossom petals
            for (i in 0..15) {
                val px = ((t * 40f + i * 90f) % (size.width + 100f)) - 50f
                val py = ((t * 25f + i * 50f) % (size.height + 60f)) - 30f
                drawCircle(
                    color = Color(0xFFFF80AB).copy(alpha = 0.75f),
                    radius = 4f,
                    center = Offset(px, py)
                )
            }
        }

        // --- Top Bar: Coins & Audio Controls ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Audio controls
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = {
                        soundEnabled = !soundEnabled
                        preferences.isSoundEnabled = soundEnabled
                        soundManager.isSoundEnabled = soundEnabled
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkCard.copy(alpha = 0.8f), CircleShape)
                        .border(1.dp, TextMuted.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "SFX",
                        tint = if (soundEnabled) StealthCyan else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = {
                        musicEnabled = !musicEnabled
                        preferences.isMusicEnabled = musicEnabled
                        soundManager.isMusicEnabled = musicEnabled
                        if (musicEnabled) soundManager.startMusic() else soundManager.stopMusic()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkCard.copy(alpha = 0.8f), CircleShape)
                        .border(1.dp, TextMuted.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (musicEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                        contentDescription = "Music",
                        tint = if (musicEnabled) Crimson else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Gold Coins Badge
            Row(
                modifier = Modifier
                    .background(DarkCard.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
                    .border(1.dp, NinjaGold.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = "Coins",
                    tint = NinjaGold,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "${preferences.coins}",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- Center Title & Menu Options ---
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Logo / Title
            Column {
                Text(
                    text = "SHADOW BLADE",
                    color = Color.White,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp
                )
                Text(
                    text = "THE PATH OF ARASHI",
                    color = Crimson,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 6.sp
                )
            }

            Spacer(Modifier.height(8.dp))

            // Play Button
            Button(
                onClick = {
                    soundManager.playSound(SoundManager.SoundType.SLASH)
                    onStartGame(preferences.unlockedLevel)
                },
                modifier = Modifier
                    .width(220.dp)
                    .height(50.dp)
                    .testTag("play_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Crimson),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "PLAY",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
            }

            // Chapters Button
            OutlinedButton(
                onClick = {
                    soundManager.playSound(SoundManager.SoundType.JUMP)
                    onOpenLevelSelect()
                },
                modifier = Modifier
                    .width(220.dp)
                    .height(46.dp)
                    .testTag("chapters_button"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Layers, contentDescription = null, tint = StealthCyan)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "CHAPTERS",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            // Dojo Upgrades Button
            OutlinedButton(
                onClick = {
                    soundManager.playSound(SoundManager.SoundType.JUMP)
                    onOpenDojo()
                },
                modifier = Modifier
                    .width(220.dp)
                    .height(46.dp)
                    .testTag("dojo_button"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Upgrade, contentDescription = null, tint = NinjaGold)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "DOJO UPGRADES",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
