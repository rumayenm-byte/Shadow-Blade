package com.example.ninja.renderer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.ninja.engine.GameEngine
import com.example.ninja.model.*
import kotlin.math.*

object GameRenderer {

    fun render(drawScope: DrawScope, engine: GameEngine, screenWidth: Float, screenHeight: Float) {
        val camX = engine.cameraX + (if (engine.screenShakeTime > 0f) (Math.random() * engine.screenShakeIntensity * 2 - engine.screenShakeIntensity).toFloat() else 0f)
        val camY = engine.cameraY + (if (engine.screenShakeTime > 0f) (Math.random() * engine.screenShakeIntensity * 2 - engine.screenShakeIntensity).toFloat() else 0f)

        // 1. Draw Atmospheric Sky Gradient
        drawSky(drawScope, engine.levelData.theme, screenWidth, screenHeight)

        // 2. Draw Parallax Background (Mountains, Moon, Pagodas, Bamboo)
        drawParallaxBackground(drawScope, engine.levelData.theme, camX, camY, screenWidth, screenHeight)

        // 3. Draw Level Platforms & Obstacles
        for (plat in engine.platforms) {
            val px = plat.x - camX
            val py = plat.y - camY
            if (px + plat.width < -50 || px > screenWidth + 50) continue

            if (plat.isBamboo) {
                drawBambooPlatform(drawScope, px, py, plat.width, plat.height)
            } else {
                drawTerrainPlatform(drawScope, px, py, plat.width, plat.height)
            }
        }

        // 4. Draw Traps
        for (trap in engine.traps) {
            val tx = trap.x - camX
            val ty = trap.y - camY
            drawTrap(drawScope, trap, tx, ty)
        }

        // 5. Draw Checkpoints & Level Exit Portal
        for (cp in engine.checkpoints) {
            drawCheckpoint(drawScope, cp, cp.x - camX, cp.y - camY)
        }
        drawPortal(drawScope, engine.levelData.portal, engine.levelData.portal.x - camX, engine.levelData.portal.y - camY)

        // 6. Draw Collectibles
        for (item in engine.collectibles) {
            if (item.collected) continue
            val ix = item.x - camX
            val iy = item.y - camY
            drawCollectible(drawScope, item, ix, iy)
        }

        // 7. Draw Enemies
        for (enemy in engine.enemies) {
            if (enemy.state == EnemyState.DEAD) continue
            val ex = enemy.x - camX
            val ey = enemy.y - camY
            if (ex < -150 || ex > screenWidth + 150) continue
            drawEnemy(drawScope, enemy, ex, ey)
        }

        // 8. Draw Projectiles
        for (p in engine.projectiles) {
            val px = p.x - camX
            val py = p.y - camY
            drawProjectile(drawScope, p, px, py)
        }

        // 9. Draw Player Ninja
        drawPlayer(drawScope, engine.player, engine.player.x - camX, engine.player.y - camY)

        // 10. Draw Particles (Sakura petals, Blood, Sparks)
        drawParticles(drawScope, engine.particles, camX, camY)
    }

    private fun drawSky(drawScope: DrawScope, theme: BackgroundTheme, width: Float, height: Float) {
        val colors = when (theme) {
            BackgroundTheme.BAMBOO_MOON -> listOf(
                Color(0xFF070B14),
                Color(0xFF0F1A2A),
                Color(0xFF162B3D)
            )
            BackgroundTheme.CRIMSON_SUNSET -> listOf(
                Color(0xFF1F0808),
                Color(0xFF4A0E17),
                Color(0xFF7E1C1C)
            )
            BackgroundTheme.SHADOW_FORTRESS -> listOf(
                Color(0xFF090C12),
                Color(0xFF141926),
                Color(0xFF1F293D)
            )
            BackgroundTheme.ECLIPSE_BLOOD_MOON -> listOf(
                Color(0xFF0D0305),
                Color(0xFF26050A),
                Color(0xFF4D000C)
            )
        }
        drawScope.drawRect(
            brush = Brush.verticalGradient(colors, startY = 0f, endY = height),
            topLeft = Offset.Zero,
            size = Size(width, height)
        )
    }

    private fun drawParallaxBackground(
        drawScope: DrawScope,
        theme: BackgroundTheme,
        camX: Float,
        camY: Float,
        width: Float,
        height: Float
    ) {
        // Moon
        val moonX = width * 0.75f - camX * 0.03f
        val moonY = height * 0.28f
        val moonRadius = if (theme == BackgroundTheme.ECLIPSE_BLOOD_MOON) 95f else 75f

        if (theme == BackgroundTheme.ECLIPSE_BLOOD_MOON) {
            // Blood Moon Eclipse with fiery corona
            drawScope.drawCircle(
                color = Color(0x66FF1744),
                radius = moonRadius + 24f,
                center = Offset(moonX, moonY)
            )
            drawScope.drawCircle(
                color = Color(0xFFFF1744),
                radius = moonRadius,
                center = Offset(moonX, moonY)
            )
            // Dark inner eclipse shadow
            drawScope.drawCircle(
                color = Color(0xFF0D0305),
                radius = moonRadius * 0.88f,
                center = Offset(moonX - 4f, moonY)
            )
        } else {
            // Luminous Japanese Harvest Moon
            drawScope.drawCircle(
                color = Color(0x44FFF9C4),
                radius = moonRadius + 30f,
                center = Offset(moonX, moonY)
            )
            drawScope.drawCircle(
                color = Color(0xFFFFFDE7),
                radius = moonRadius,
                center = Offset(moonX, moonY)
            )
        }

        // Parallax Layer 1: Distant Mountains (0.1x speed)
        val mountainOffset = -(camX * 0.08f) % 800f
        val mountainPath = Path().apply {
            moveTo(mountainOffset - 400f, height)
            var x = mountainOffset - 400f
            while (x < width + 800f) {
                lineTo(x + 200f, height * 0.48f)
                lineTo(x + 400f, height * 0.62f)
                lineTo(x + 600f, height * 0.42f)
                lineTo(x + 800f, height * 0.65f)
                x += 800f
            }
            lineTo(width + 800f, height)
            close()
        }
        drawScope.drawPath(
            path = mountainPath,
            color = Color(0x33000000)
        )

        // Parallax Layer 2: Pagodas & Ancient Temple Silhouettes (0.2x speed)
        val midOffset = -(camX * 0.18f) % 900f
        val pagodaX = midOffset + 400f
        if (pagodaX in -200f..width + 200f) {
            drawPagodaSilhouette(drawScope, pagodaX, height * 0.68f)
        }
        val pagodaX2 = midOffset + 850f
        if (pagodaX2 in -200f..width + 200f) {
            drawToriiSilhouette(drawScope, pagodaX2, height * 0.70f)
        }

        // Parallax Layer 3: Bamboo forest silhouettes in background (0.35x speed)
        val bambooOffset = -(camX * 0.35f) % 300f
        var bx = bambooOffset - 100f
        while (bx < width + 100f) {
            drawScope.drawLine(
                color = Color(0x4405080E),
                start = Offset(bx, height),
                end = Offset(bx + 15f, height * 0.45f),
                strokeWidth = 14f
            )
            drawScope.drawLine(
                color = Color(0x4405080E),
                start = Offset(bx + 45f, height),
                end = Offset(bx + 55f, height * 0.48f),
                strokeWidth = 10f
            )
            bx += 160f
        }
    }

    private fun drawPagodaSilhouette(drawScope: DrawScope, x: Float, baseY: Float) {
        val color = Color(0x55000000)
        // 3-tiered pagoda silhouette
        val path = Path().apply {
            // Tier 1 (bottom)
            moveTo(x - 55f, baseY)
            lineTo(x + 55f, baseY)
            lineTo(x + 35f, baseY - 45f)
            lineTo(x + 65f, baseY - 50f) // curved eave
            lineTo(x - 65f, baseY - 50f)
            lineTo(x - 35f, baseY - 45f)
            close()
            // Tier 2 (middle)
            moveTo(x - 32f, baseY - 50f)
            lineTo(x + 32f, baseY - 50f)
            lineTo(x + 22f, baseY - 85f)
            lineTo(x + 48f, baseY - 90f)
            lineTo(x - 48f, baseY - 90f)
            lineTo(x - 22f, baseY - 85f)
            close()
            // Tier 3 (top)
            moveTo(x - 20f, baseY - 90f)
            lineTo(x + 20f, baseY - 90f)
            lineTo(x + 12f, baseY - 120f)
            lineTo(x + 32f, baseY - 125f)
            lineTo(x - 32f, baseY - 125f)
            lineTo(x - 12f, baseY - 120f)
            close()
            // Spire
            moveTo(x - 3f, baseY - 125f)
            lineTo(x + 3f, baseY - 125f)
            lineTo(x, baseY - 155f)
            close()
        }
        drawScope.drawPath(path, color)
    }

    private fun drawToriiSilhouette(drawScope: DrawScope, x: Float, baseY: Float) {
        val color = Color(0x55000000)
        // Pillars
        drawScope.drawRect(color, topLeft = Offset(x - 28f, baseY - 70f), size = Size(8f, 70f))
        drawScope.drawRect(color, topLeft = Offset(x + 20f, baseY - 70f), size = Size(8f, 70f))
        // Top lintels
        drawScope.drawRect(color, topLeft = Offset(x - 38f, baseY - 75f), size = Size(76f, 7f))
        drawScope.drawRect(color, topLeft = Offset(x - 44f, baseY - 85f), size = Size(88f, 8f))
    }

    private fun drawTerrainPlatform(drawScope: DrawScope, x: Float, y: Float, w: Float, h: Float) {
        // Pure shadow black ground
        drawScope.drawRect(
            color = Color(0xFF090C12),
            topLeft = Offset(x, y),
            size = Size(w, h)
        )
        // Top edge grass/moss highlight
        drawScope.drawLine(
            color = Color(0xFF1E2838),
            start = Offset(x, y),
            end = Offset(x + w, y),
            strokeWidth = 3f
        )
        // Little grass tufts along top edge
        var gx = x + 15f
        while (gx < x + w - 10f) {
            drawScope.drawLine(
                color = Color(0xFF090C12),
                start = Offset(gx, y),
                end = Offset(gx - 3f, y - 6f),
                strokeWidth = 2.5f
            )
            drawScope.drawLine(
                color = Color(0xFF090C12),
                start = Offset(gx + 4f, y),
                end = Offset(gx + 6f, y - 7f),
                strokeWidth = 2.5f
            )
            gx += 45f
        }
    }

    private fun drawBambooPlatform(drawScope: DrawScope, x: Float, y: Float, w: Float, h: Float) {
        // Bamboo stalk bridge
        drawScope.drawRoundRect(
            color = Color(0xFF090C12),
            topLeft = Offset(x, y),
            size = Size(w, h),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )
        // Segment joints
        var jx = x + 25f
        while (jx < x + w - 10f) {
            drawScope.drawLine(
                color = Color(0xFF1E2838),
                start = Offset(jx, y),
                end = Offset(jx, y + h),
                strokeWidth = 3f
            )
            jx += 35f
        }
    }

    private fun drawTrap(drawScope: DrawScope, trap: Trap, tx: Float, ty: Float) {
        when (trap.type) {
            TrapType.SPIKE_PIT -> {
                // Pointy deadly spikes
                var sx = tx
                val spikeWidth = 18f
                while (sx < tx + trap.width) {
                    val p = Path().apply {
                        moveTo(sx, ty + trap.height)
                        lineTo(sx + spikeWidth / 2f, ty)
                        lineTo(sx + spikeWidth, ty + trap.height)
                        close()
                    }
                    drawScope.drawPath(p, Color(0xFF090C12))
                    // Metallic red gleam on spike tip
                    drawScope.drawLine(
                        color = Color(0xFFFF3344),
                        start = Offset(sx + spikeWidth / 2f, ty),
                        end = Offset(sx + spikeWidth / 2f, ty + 8f),
                        strokeWidth = 2f
                    )
                    sx += spikeWidth
                }
            }

            TrapType.SPINNING_SAW -> {
                val radius = trap.width / 2f
                val rot = (System.currentTimeMillis() % 1000) / 1000f * 360f
                drawScope.rotate(rot, pivot = Offset(tx, ty)) {
                    // Saw blade center disc
                    drawCircle(Color(0xFF1A1F2C), radius = radius, center = Offset(tx, ty))
                    // Teeth
                    for (i in 0 until 8) {
                        val angle = (i * 45) * PI.toFloat() / 180f
                        val toothX = tx + cos(angle) * (radius + 6f)
                        val toothY = ty + sin(angle) * (radius + 6f)
                        drawLine(
                            color = Color(0xFFFF3344),
                            start = Offset(tx + cos(angle) * radius * 0.7f, ty + sin(angle) * radius * 0.7f),
                            end = Offset(toothX, toothY),
                            strokeWidth = 4f
                        )
                    }
                    drawCircle(Color(0xFF090C12), radius = radius * 0.4f, center = Offset(tx, ty))
                }
            }

            TrapType.SWINGING_MACE -> {
                val maceX = trap.pivotX - (trap.x - tx) + sin(trap.angle) * trap.chainLength
                val maceY = trap.pivotY - (trap.y - ty) + cos(trap.angle) * trap.chainLength
                val pX = trap.pivotX - (trap.x - tx)
                val pY = trap.pivotY - (trap.y - ty)

                // Chain
                drawScope.drawLine(
                    color = Color(0xFF1E2838),
                    start = Offset(pX, pY),
                    end = Offset(maceX, maceY),
                    strokeWidth = 4f
                )
                // Spiked mace head
                drawScope.drawCircle(
                    color = Color(0xFF090C12),
                    radius = trap.width / 2f,
                    center = Offset(maceX, maceY)
                )
                // Red glowing spikes on mace
                for (i in 0 until 6) {
                    val a = (i * 60) * PI.toFloat() / 180f
                    val spkX = maceX + cos(a) * (trap.width / 2f + 8f)
                    val spkY = maceY + sin(a) * (trap.width / 2f + 8f)
                    drawScope.drawLine(
                        color = Color(0xFFFF3344),
                        start = Offset(maceX + cos(a) * (trap.width / 2f), maceY + sin(a) * (trap.width / 2f)),
                        end = Offset(spkX, spkY),
                        strokeWidth = 3f
                    )
                }
            }

            TrapType.DART_SHOOTER -> {
                // Wall mask / demonic gargoyle mouth
                drawScope.drawRect(
                    color = Color(0xFF090C12),
                    topLeft = Offset(tx, ty),
                    size = Size(trap.width, trap.height)
                )
                drawScope.drawCircle(
                    color = Color(0xFFFF1744),
                    radius = 4f,
                    center = Offset(tx + trap.width / 2f, ty + trap.height / 2f)
                )
            }
            TrapType.CRUMBLING_PLATFORM -> {}
        }
    }

    private fun drawCheckpoint(drawScope: DrawScope, cp: Checkpoint, x: Float, y: Float) {
        // Stone lantern shrine
        val color = Color(0xFF090C12)
        // Base
        drawScope.drawRect(color, topLeft = Offset(x - 14f, y - 10f), size = Size(28f, 10f))
        // Pillar
        drawScope.drawRect(color, topLeft = Offset(x - 6f, y - 38f), size = Size(12f, 28f))
        // Lantern chamber
        drawScope.drawRect(color, topLeft = Offset(x - 12f, y - 52f), size = Size(24f, 14f))
        // Roof
        val roof = Path().apply {
            moveTo(x - 18f, y - 52f)
            lineTo(x + 18f, y - 52f)
            lineTo(x, y - 62f)
            close()
        }
        drawScope.drawPath(roof, color)

        // Flame
        val flameColor = if (cp.activated) Color(0xFF00E5FF) else Color(0x6690A4AE)
        val flameRadius = if (cp.activated) 6f + sin(System.currentTimeMillis() * 0.008f) * 1.5f else 4f
        drawScope.drawCircle(
            color = flameColor,
            radius = flameRadius,
            center = Offset(x, y - 45f)
        )
        if (cp.activated) {
            // Spiritual blue glow
            drawScope.drawCircle(
                color = Color(0x3300E5FF),
                radius = flameRadius + 12f,
                center = Offset(x, y - 45f)
            )
        }
    }

    private fun drawPortal(drawScope: DrawScope, portal: Portal, x: Float, y: Float) {
        // Sacred Torii exit gate with swirling misty vortex
        val color = Color(0xFF090C12)
        // Posts
        drawScope.drawRect(color, topLeft = Offset(x + 6f, y - portal.height), size = Size(8f, portal.height))
        drawScope.drawRect(color, topLeft = Offset(x + portal.width - 14f, y - portal.height), size = Size(8f, portal.height))
        // Top lintels
        drawScope.drawRect(color, topLeft = Offset(x - 6f, y - portal.height - 4f), size = Size(portal.width + 12f, 8f))
        drawScope.drawRect(color, topLeft = Offset(x - 12f, y - portal.height - 14f), size = Size(portal.width + 24f, 10f))

        // Mystic Gateway Swirl
        val portalTime = System.currentTimeMillis() * 0.003f
        val pulse = 14f + sin(portalTime * 2f) * 4f
        drawScope.drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF00E5FF), Color(0x4400E5FF), Color.Transparent),
                center = Offset(x + portal.width / 2f, y - portal.height / 2f),
                radius = pulse + 20f
            ),
            radius = pulse + 20f,
            center = Offset(x + portal.width / 2f, y - portal.height / 2f)
        )
    }

    private fun drawCollectible(drawScope: DrawScope, item: Collectible, x: Float, y: Float) {
        val bob = sin((System.currentTimeMillis() + item.id * 200) * 0.005f) * 5f
        val cy = y + bob

        when (item.type) {
            CollectibleType.COIN -> {
                // Gold Ninja Mon (coin with center square hole)
                val coinRadius = 10f
                drawScope.drawCircle(
                    color = Color(0xFFFFD54F),
                    radius = coinRadius,
                    center = Offset(x, cy)
                )
                drawScope.drawCircle(
                    color = Color(0xFFFFB300),
                    radius = coinRadius * 0.75f,
                    center = Offset(x, cy),
                    style = Stroke(width = 1.5f)
                )
                // Center square hole
                drawScope.drawRect(
                    color = Color(0xFF090C12),
                    topLeft = Offset(x - 2.5f, cy - 2.5f),
                    size = Size(5f, 5f)
                )
            }

            CollectibleType.SCROLL -> {
                // Ancient Shinobi Scroll
                val glowRad = 16f + sin(System.currentTimeMillis() * 0.008f) * 3f
                drawScope.drawCircle(
                    color = Color(0x4400E5FF),
                    radius = glowRad,
                    center = Offset(x, cy)
                )
                // Scroll parchment body
                drawScope.drawRoundRect(
                    color = Color(0xFFFFF9C4),
                    topLeft = Offset(x - 14f, cy - 8f),
                    size = Size(28f, 16f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
                )
                // Crimson ribbon band
                drawScope.drawRect(
                    color = Color(0xFFFF1744),
                    topLeft = Offset(x - 3f, cy - 8f),
                    size = Size(6f, 16f)
                )
                // Wooden dowel caps
                drawScope.drawRect(Color(0xFF5D4037), topLeft = Offset(x - 16f, cy - 10f), size = Size(3f, 20f))
                drawScope.drawRect(Color(0xFF5D4037), topLeft = Offset(x + 13f, cy - 10f), size = Size(3f, 20f))
            }

            CollectibleType.HEART -> {
                // Healing Heart
                val heartPath = Path().apply {
                    moveTo(x, cy - 4f)
                    cubicTo(x - 8f, cy - 16f, x - 16f, cy, x, cy + 12f)
                    moveTo(x, cy - 4f)
                    cubicTo(x + 8f, cy - 16f, x + 16f, cy, x, cy + 12f)
                    close()
                }
                drawScope.drawPath(heartPath, Color(0xFFFF1744))
            }
        }
    }

    private fun drawEnemy(drawScope: DrawScope, enemy: Enemy, x: Float, y: Float) {
        val facingRight = enemy.facingRight
        val dir = if (facingRight) 1f else -1f

        if (enemy.isBoss) {
            drawBossKuro(drawScope, enemy, x, y, facingRight)
            return
        }

        val color = if (enemy.hurtTimer > 0f) Color(0xFFFF5252) else Color(0xFF090C12)

        when (enemy.type) {
            EnemyType.ASHIGARU -> {
                // Foot Soldier with Spear & Conical Hat
                // Legs
                drawScope.drawRect(color, topLeft = Offset(x - 8f, y - 24f), size = Size(6f, 24f))
                drawScope.drawRect(color, topLeft = Offset(x + 2f, y - 24f), size = Size(6f, 24f))
                // Torso & armor
                drawScope.drawRect(color, topLeft = Offset(x - 10f, y - 42f), size = Size(20f, 20f))
                // Head
                drawScope.drawCircle(color, radius = 8f, center = Offset(x, y - 48f))
                // Jingasa (conical hat)
                val hat = Path().apply {
                    moveTo(x - 18f, y - 48f)
                    lineTo(x + 18f, y - 48f)
                    lineTo(x, y - 58f)
                    close()
                }
                drawScope.drawPath(hat, color)
                // Red glowing eye
                drawScope.drawCircle(
                    color = Color(0xFFFF1744),
                    radius = 2.5f,
                    center = Offset(x + dir * 4f, y - 48f)
                )
                // Spear
                val spearY = y - 32f
                drawScope.drawLine(
                    color = Color(0xFF37474F),
                    start = Offset(x - dir * 15f, spearY + 8f),
                    end = Offset(x + dir * 35f, spearY - 6f),
                    strokeWidth = 3f
                )
                // Spearhead
                val spearHead = Path().apply {
                    moveTo(x + dir * 35f, spearY - 6f)
                    lineTo(x + dir * 45f, spearY - 8f)
                    lineTo(x + dir * 33f, spearY - 2f)
                    close()
                }
                drawScope.drawPath(spearHead, Color(0xFFFF5252))
            }

            EnemyType.ARCHER -> {
                // Shadow Bow Ninja
                drawScope.drawRect(color, topLeft = Offset(x - 7f, y - 22f), size = Size(5f, 22f))
                drawScope.drawRect(color, topLeft = Offset(x + 2f, y - 22f), size = Size(5f, 22f))
                drawScope.drawRect(color, topLeft = Offset(x - 8f, y - 40f), size = Size(16f, 20f))
                drawScope.drawCircle(color, radius = 7f, center = Offset(x, y - 45f))
                // Bow
                val bowX = x + dir * 14f
                val bowY = y - 32f
                drawScope.drawArc(
                    color = Color(0xFF5D4037),
                    startAngle = if (facingRight) -80f else 100f,
                    sweepAngle = 160f,
                    useCenter = false,
                    topLeft = Offset(bowX - 12f, bowY - 18f),
                    size = Size(24f, 36f),
                    style = Stroke(width = 3f)
                )
                // Eye
                drawScope.drawCircle(
                    color = Color(0xFFFF9100),
                    radius = 2.5f,
                    center = Offset(x + dir * 3f, y - 45f)
                )
            }

            EnemyType.ASSASSIN -> {
                // Agile dual blade shadow
                drawScope.drawRect(color, topLeft = Offset(x - 9f, y - 24f), size = Size(6f, 24f))
                drawScope.drawRect(color, topLeft = Offset(x + 3f, y - 24f), size = Size(6f, 24f))
                drawScope.drawRect(color, topLeft = Offset(x - 10f, y - 42f), size = Size(20f, 20f))
                drawScope.drawCircle(color, radius = 8f, center = Offset(x, y - 48f))
                // Twin glowing cyan/violet blades
                val b1 = Offset(x + dir * 26f, y - 30f)
                drawScope.drawLine(Color(0xFFE040FB), start = Offset(x, y - 30f), end = b1, strokeWidth = 3f)
                val b2 = Offset(x - dir * 18f, y - 45f)
                drawScope.drawLine(Color(0xFFE040FB), start = Offset(x, y - 38f), end = b2, strokeWidth = 3f)
                // Eye
                drawScope.drawCircle(Color(0xFFE040FB), radius = 2.5f, center = Offset(x + dir * 4f, y - 48f))
            }

            EnemyType.SHIELD_BRUTE -> {
                // Towering shield samurai
                drawScope.drawRect(color, topLeft = Offset(x - 12f, y - 28f), size = Size(10f, 28f))
                drawScope.drawRect(color, topLeft = Offset(x + 2f, y - 28f), size = Size(10f, 28f))
                drawScope.drawRect(color, topLeft = Offset(x - 14f, y - 54f), size = Size(28f, 28f))
                drawScope.drawCircle(color, radius = 10f, center = Offset(x, y - 60f))
                // Giant Shield on front
                val sX = if (facingRight) x + 10f else x - 26f
                drawScope.drawRoundRect(
                    color = Color(0xFF263238),
                    topLeft = Offset(sX, y - 56f),
                    size = Size(16f, 56f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )
                // Shield crest
                drawScope.drawCircle(
                    color = Color(0xFFFFD54F),
                    radius = 4f,
                    center = Offset(sX + 8f, y - 28f)
                )
                // Horns on helmet
                drawScope.drawLine(color, start = Offset(x - 6f, y - 66f), end = Offset(x - 12f, y - 76f), strokeWidth = 3f)
                drawScope.drawLine(color, start = Offset(x + 6f, y - 66f), end = Offset(x + 12f, y - 76f), strokeWidth = 3f)
            }
            EnemyType.BOSS_KURO -> {}
        }

        // Enemy Health Bar (if damaged)
        if (enemy.health < enemy.maxHealth) {
            val barW = 36f
            val barH = 5f
            val barX = x - barW / 2f
            val barY = y - enemy.height - 14f
            drawScope.drawRect(Color(0x88000000), topLeft = Offset(barX, barY), size = Size(barW, barH))
            val hpRatio = (enemy.health / enemy.maxHealth).coerceIn(0f, 1f)
            drawScope.drawRect(Color(0xFFFF1744), topLeft = Offset(barX, barY), size = Size(barW * hpRatio, barH))
        }
    }

    private fun drawBossKuro(drawScope: DrawScope, boss: Enemy, x: Float, y: Float, facingRight: Boolean) {
        val color = if (boss.hurtTimer > 0f) Color(0xFFFF5252) else Color(0xFF090C12)
        val dir = if (facingRight) 1f else -1f

        // Demon Aura (Phase 2)
        if (boss.bossPhase == 2) {
            drawScope.drawCircle(
                color = Color(0x33FF1744),
                radius = 65f,
                center = Offset(x, y - 48f)
            )
        }

        // Heavy Legs
        drawScope.drawRect(color, topLeft = Offset(x - 18f, y - 36f), size = Size(14f, 36f))
        drawScope.drawRect(color, topLeft = Offset(x + 4f, y - 36f), size = Size(14f, 36f))
        // Bulky Samurai Armor / Haori
        drawScope.drawRect(color, topLeft = Offset(x - 24f, y - 76f), size = Size(48f, 42f))
        // Shoulder pads (Sode)
        drawScope.drawRect(color, topLeft = Offset(x - 34f, y - 76f), size = Size(12f, 26f))
        drawScope.drawRect(color, topLeft = Offset(x + 22f, y - 76f), size = Size(12f, 26f))
        // Head / Oni Mask
        drawScope.drawCircle(color, radius = 16f, center = Offset(x, y - 84f))
        // Ominous Demon Horns
        val h1 = Path().apply {
            moveTo(x - 8f, y - 94f)
            lineTo(x - 22f, y - 114f)
            lineTo(x - 14f, y - 94f)
            close()
        }
        val h2 = Path().apply {
            moveTo(x + 8f, y - 94f)
            lineTo(x + 22f, y - 114f)
            lineTo(x + 14f, y - 94f)
            close()
        }
        drawScope.drawPath(h1, color)
        drawScope.drawPath(h2, color)

        // Glowing Crimson Demon Eyes
        drawScope.drawCircle(Color(0xFFFF1744), radius = 4f, center = Offset(x - 4f + dir * 5f, y - 84f))
        drawScope.drawCircle(Color(0xFFFF1744), radius = 4f, center = Offset(x + 4f + dir * 5f, y - 84f))

        // Giant Nodachi Katana
        val swordHilt = Offset(x + dir * 18f, y - 60f)
        val swordTip = Offset(x + dir * 75f, y - 95f)
        drawScope.drawLine(
            color = if (boss.bossPhase == 2) Color(0xFFFF1744) else Color(0xFFECEFF1),
            start = swordHilt,
            end = swordTip,
            strokeWidth = 6f
        )
    }

    private fun drawProjectile(drawScope: DrawScope, p: Projectile, x: Float, y: Float) {
        when (p.type) {
            ProjectileType.SHURIKEN -> {
                // 4-pointed spinning ninja shuriken
                val radius = p.radius
                drawScope.rotate(p.rotation, pivot = Offset(x, y)) {
                    val path = Path().apply {
                        moveTo(x, y - radius)
                        lineTo(x + radius * 0.3f, y - radius * 0.3f)
                        lineTo(x + radius, y)
                        lineTo(x + radius * 0.3f, y + radius * 0.3f)
                        lineTo(x, y + radius)
                        lineTo(x - radius * 0.3f, y + radius * 0.3f)
                        lineTo(x - radius, y)
                        lineTo(x - radius * 0.3f, y - radius * 0.3f)
                        close()
                    }
                    drawPath(path, Color(0xFFECEFF1))
                    drawCircle(Color(0xFF090C12), radius = radius * 0.3f, center = Offset(x, y))
                }
            }

            ProjectileType.ARROW -> {
                // Flaming shadow arrow
                val dir = if (p.vx > 0) 1f else -1f
                drawScope.drawLine(
                    color = Color(0xFFECEFF1),
                    start = Offset(x - dir * 18f, y),
                    end = Offset(x + dir * 8f, y),
                    strokeWidth = 2.5f
                )
                // Fire tip
                drawScope.drawCircle(Color(0xFFFF5722), radius = 4f, center = Offset(x + dir * 8f, y))
            }

            ProjectileType.DART -> {
                drawScope.drawCircle(Color(0xFF00E676), radius = 4f, center = Offset(x, y))
            }

            ProjectileType.BOSS_SHOCKWAVE -> {
                // Traveling ground energy wave
                val waveH = 40f
                val path = Path().apply {
                    moveTo(x - 18f, y)
                    lineTo(x, y - waveH)
                    lineTo(x + 18f, y)
                    close()
                }
                drawScope.drawPath(path, Color(0xFFFF1744))
                drawScope.drawCircle(Color(0xFFFF5252), radius = 16f, center = Offset(x, y - waveH * 0.5f))
            }
        }
    }

    private fun drawPlayer(drawScope: DrawScope, player: Player, x: Float, y: Float) {
        val facingRight = player.facingRight
        val dir = if (facingRight) 1f else -1f

        // Draw Ghost Trails (Shadow Dash)
        for (ghost in player.ghostTrails) {
            val gx = ghost.x - (player.x - x)
            val gy = ghost.y - (player.y - y)
            drawScope.drawCircle(
                color = Color(0x3300E5FF).copy(alpha = ghost.alpha * 0.4f),
                radius = 24f,
                center = Offset(gx, gy - 27f)
            )
        }

        // Invulnerability flashing
        if (player.invulnerableTimer > 0f && (player.invulnerableTimer * 20).toInt() % 2 == 0) {
            return
        }

        val ninjaColor = Color(0xFF090C12)

        // Somersault rotation during double jump
        val isFlipping = !player.canDoubleJump && !player.isGrounded && player.vy < 0f
        val flipAngle = if (isFlipping) (player.animTimer * 1000f) % 360f else 0f

        val isSlashing = player.slashTimer > 0f || player.state == PlayerState.SLASHING
        val slashProgress = if (isSlashing) (1f - (player.slashTimer / 0.35f)).coerceIn(0f, 1f) else 0f

        drawScope.rotate(flipAngle, pivot = Offset(x, y - 27f)) {
            // Legs (dynamic combat lunge during slash, or running/jumping poses)
            val legAnim = sin(player.animTimer * 14f) * 8f
            val leg1X = if (isSlashing) x + dir * 14f else if (player.state == PlayerState.RUNNING) x - 6f + legAnim else x - 6f
            val leg2X = if (isSlashing) x - dir * 12f else if (player.state == PlayerState.RUNNING) x + 6f - legAnim else x + 4f
            val leg1Y = if (isSlashing) y - 3f else y
            val leg2Y = y
            drawLine(ninjaColor, start = Offset(x, y - 24f), end = Offset(leg1X, leg1Y), strokeWidth = 5.5f)
            drawLine(ninjaColor, start = Offset(x, y - 24f), end = Offset(leg2X, leg2Y), strokeWidth = 5.5f)

            // Torso (leaning forward into attack)
            val torsoLeanX = if (isSlashing) dir * 5f else 0f
            drawRect(ninjaColor, topLeft = Offset(x - 9f + torsoLeanX, y - 42f), size = Size(18f, 20f))

            // Head & Mask
            val headX = x + torsoLeanX
            drawCircle(ninjaColor, radius = 9f, center = Offset(headX, y - 47f))

            // Glowing stealth eye slit (Iconic Arashi white/cyan eye)
            drawCircle(
                color = Color(0xFF00E5FF),
                radius = 2.5f,
                center = Offset(headX + dir * 4f, y - 47f)
            )

            // Fluttering Crimson Scarf (Dynamic cloth physics)
            val scarfWave = sin(player.animTimer * 10f) * 6f
            val scarfPath = Path().apply {
                moveTo(headX - dir * 4f, y - 43f)
                cubicTo(
                    headX - dir * 18f, y - 45f + scarfWave,
                    headX - dir * 28f, y - 38f - scarfWave,
                    headX - dir * 44f, y - 42f + scarfWave * 1.5f
                )
                lineTo(headX - dir * 42f, y - 36f + scarfWave * 1.5f)
                cubicTo(
                    headX - dir * 26f, y - 32f - scarfWave,
                    headX - dir * 16f, y - 39f + scarfWave,
                    headX - dir * 4f, y - 40f
                )
                close()
            }
            drawPath(scarfPath, Color(0xFFFF1744))

            // Katana & Striking Arm
            if (isSlashing) {
                // Dynamic sword swing angle: sweeps from raised high back (-85 deg) down to forward strike (+45 deg)
                val swingAngleDeg = -85f + slashProgress * 135f
                val swingRad = swingAngleDeg * PI.toFloat() / 180f

                val hiltX = x + dir * 8f + torsoLeanX
                val hiltY = y - 32f
                val bladeLen = 46f
                val tipX = hiltX + cos(swingRad) * bladeLen * dir
                val tipY = hiltY + sin(swingRad) * bladeLen

                // Extended striking arm
                drawLine(ninjaColor, start = Offset(headX, y - 36f), end = Offset(hiltX, hiltY), strokeWidth = 5f)
                // Golden tsuba handguard
                drawCircle(Color(0xFFFFD54F), radius = 3.5f, center = Offset(hiltX, hiltY))
                // Gleaming katana blade (thick steel blade with white razor edge)
                drawLine(Color(0xFFB0BEC5), start = Offset(hiltX, hiltY), end = Offset(tipX, tipY), strokeWidth = 5f)
                drawLine(Color.White, start = Offset(hiltX, hiltY), end = Offset(tipX, tipY), strokeWidth = 2.5f)

                // Luminous Curved Slash Arc Blade Wave
                val arcRadius = 58f
                val arcCenter = Offset(x + dir * 16f, y - 30f)
                val arcStartAngle = if (facingRight) -75f else 115f
                val arcSweep = if (facingRight) 130f else -130f
                val sweepFrac = (slashProgress * 0.85f + 0.15f).coerceIn(0.15f, 1f)

                // Outer cyan energy wave
                drawArc(
                    color = Color(0x9900E5FF),
                    startAngle = arcStartAngle,
                    sweepAngle = arcSweep * sweepFrac,
                    useCenter = false,
                    topLeft = Offset(arcCenter.x - arcRadius, arcCenter.y - arcRadius),
                    size = Size(arcRadius * 2f, arcRadius * 2f),
                    style = Stroke(width = 7f)
                )
                // Inner pure white razor crest
                drawArc(
                    color = Color.White,
                    startAngle = arcStartAngle,
                    sweepAngle = arcSweep * sweepFrac,
                    useCenter = false,
                    topLeft = Offset(arcCenter.x - arcRadius * 0.95f, arcCenter.y - arcRadius * 0.95f),
                    size = Size(arcRadius * 1.9f, arcRadius * 1.9f),
                    style = Stroke(width = 3.5f)
                )
            } else {
                // Sheathed Katana across back
                drawLine(
                    color = Color(0xFF78909C),
                    start = Offset(x - dir * 10f, y - 22f),
                    end = Offset(x + dir * 8f, y - 56f),
                    strokeWidth = 3.5f
                )
            }
        }
    }

    private fun drawParticles(drawScope: DrawScope, particles: List<Particle>, camX: Float, camY: Float) {
        for (p in particles) {
            val px = p.x - camX
            val py = p.y - camY
            val col = Color(p.color).copy(alpha = p.alpha)

            when (p.type) {
                ParticleType.SAKURA_PETAL -> {
                    // Delicate floating pink cherry blossom petal
                    val path = Path().apply {
                        moveTo(px, py - p.size)
                        cubicTo(px + p.size, py, px, py + p.size, px - p.size, py)
                        close()
                    }
                    drawScope.drawPath(path, col)
                }

                ParticleType.BLOOD_SPURT, ParticleType.SPARK -> {
                    drawScope.drawCircle(color = col, radius = p.size / 2f, center = Offset(px, py))
                }

                ParticleType.DUST -> {
                    drawScope.drawCircle(color = col, radius = p.size, center = Offset(px, py))
                }

                ParticleType.SHOCKWAVE_RING -> {
                    drawScope.drawCircle(
                        color = col,
                        radius = p.size * (1f - p.lifetime / p.maxLifetime + 0.2f),
                        center = Offset(px, py),
                        style = Stroke(width = 2.5f)
                    )
                }

                ParticleType.SLASH_TRAIL -> {
                    drawScope.drawArc(
                        color = col,
                        startAngle = -45f,
                        sweepAngle = 90f,
                        useCenter = false,
                        topLeft = Offset(px - p.size, py - p.size),
                        size = Size(p.size * 2f, p.size * 2f),
                        style = Stroke(width = 4f)
                    )
                }
            }
        }
    }
}
