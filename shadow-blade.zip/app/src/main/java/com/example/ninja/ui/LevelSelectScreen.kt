package com.example.ninja.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ui.theme.*

data class ChapterMeta(
    val index: Int,
    val title: String,
    val subtitle: String,
    val description: String,
    val isBoss: Boolean = false
)

@Composable
fun LevelSelectScreen(
    preferences: GamePreferences,
    soundManager: SoundManager,
    onSelectLevel: (Int) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val chapters = listOf(
        ChapterMeta(
            index = 1,
            title = "Whispering Bamboo",
            subtitle = "Chapter I",
            description = "Master the art of stealth and acrobatics through the ancient bamboo grove."
        ),
        ChapterMeta(
            index = 2,
            title = "Crimson Shrine",
            subtitle = "Chapter II",
            description = "Navigate temple rooftops fraught with swinging blades and shadow archers."
        ),
        ChapterMeta(
            index = 3,
            title = "Shadow Fortress",
            subtitle = "Chapter III",
            description = "Infiltrate the warlord's fortress guarded by shield samurai and buzz saws."
        ),
        ChapterMeta(
            index = 4,
            title = "Warlord's Throne",
            subtitle = "Chapter IV - Boss Battle",
            description = "Defeat the Corrupted Warlord Lord Kuro beneath the blood moon eclipse.",
            isBoss = true
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian)
            .padding(horizontal = 24.dp, vertical = 18.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .background(DarkCard, CircleShape)
                            .border(1.dp, TextMuted.copy(alpha = 0.4f), CircleShape)
                            .testTag("back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = "SELECT CHAPTER",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }

                // Coins
                Row(
                    modifier = Modifier
                        .background(DarkCard, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NinjaGold, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("${preferences.coins}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(18.dp))

            // Horizontal Chapter Cards
            LazyRow(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                contentPadding = PaddingValues(end = 32.dp)
            ) {
                itemsIndexed(chapters) { _, chapter ->
                    val isUnlocked = chapter.index <= preferences.unlockedLevel
                    val stars = preferences.getLevelStars(chapter.index)

                    Box(
                        modifier = Modifier
                            .width(260.dp)
                            .height(280.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    if (isUnlocked) {
                                        if (chapter.isBoss) listOf(Color(0xFF2E090F), DarkCard)
                                        else listOf(DarkSurface, DarkCard)
                                    } else {
                                        listOf(DarkCard.copy(alpha = 0.4f), Obsidian)
                                    }
                                )
                            )
                            .border(
                                width = if (chapter.isBoss && isUnlocked) 2.dp else 1.dp,
                                color = if (isUnlocked) {
                                    if (chapter.isBoss) BloodMoon else Crimson.copy(alpha = 0.6f)
                                } else TextMuted.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable(enabled = isUnlocked) {
                                soundManager.playSound(SoundManager.SoundType.SLASH)
                                onSelectLevel(chapter.index)
                            }
                            .padding(18.dp)
                            .testTag("chapter_card_${chapter.index}")
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top Row: Subtitle & Status
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = chapter.subtitle.uppercase(),
                                    color = if (chapter.isBoss) BloodMoon else StealthCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                if (!isUnlocked) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Locked",
                                        tint = TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    // Stars
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        for (s in 1..3) {
                                            Icon(
                                                imageVector = if (s <= stars) Icons.Default.Star else Icons.Default.StarBorder,
                                                contentDescription = null,
                                                tint = if (s <= stars) NinjaGold else TextMuted.copy(alpha = 0.4f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Middle: Title & Description
                            Column {
                                Text(
                                    text = chapter.title,
                                    color = if (isUnlocked) Color.White else TextMuted,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = chapter.description,
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }

                            // Bottom: Scrolls found & Action Button
                            if (isUnlocked) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Scrolls indicators
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        for (sc in 1..3) {
                                            val found = preferences.isScrollFound(chapter.index, sc)
                                            Icon(
                                                imageVector = Icons.Default.MenuBook,
                                                contentDescription = null,
                                                tint = if (found) StealthCyan else TextMuted.copy(alpha = 0.3f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            soundManager.playSound(SoundManager.SoundType.SLASH)
                                            onSelectLevel(chapter.index)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (chapter.isBoss) BloodMoon else Crimson),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Text("ENTER", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                Text(
                                    text = "Clear previous chapter to unlock",
                                    color = TextMuted.copy(alpha = 0.6f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
