package com.example.ninja.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ninja.engine.GameEngine
import com.example.ninja.engine.LevelBuilder
import com.example.ninja.model.EnemyType
import android.view.KeyEvent
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.*
import com.example.ninja.renderer.GameRenderer
import com.example.ui.theme.*

@Composable
fun GameScreen(
    levelIndex: Int,
    preferences: GamePreferences,
    soundManager: SoundManager,
    onBackToMenu: () -> Unit,
    onNextLevel: () -> Unit
) {
    var currentLevelIdx by remember { mutableIntStateOf(levelIndex) }
    var engine by remember(currentLevelIdx) {
        val levelData = LevelBuilder.buildLevel(currentLevelIdx)
        mutableStateOf(GameEngine(levelData, preferences, soundManager))
    }

    var isPaused by remember { mutableStateOf(false) }

    // Sound toggle states
    var soundEnabled by remember { mutableStateOf(preferences.isSoundEnabled) }
    var musicEnabled by remember { mutableStateOf(preferences.isMusicEnabled) }

    BackHandler {
        if (!isPaused && !engine.isGameOver && !engine.isVictory) {
            isPaused = true
        } else {
            onBackToMenu()
        }
    }

    // 60 FPS Game Loop
    var frameTick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(engine, isPaused) {
        var lastNanoTime = 0L
        while (!isPaused) {
            withFrameNanos { now ->
                if (lastNanoTime != 0L) {
                    val dt = (now - lastNanoTime) / 1_000_000_000f
                    engine.update(dt)
                    frameTick = now
                }
                lastNanoTime = now
            }
        }
    }

    val focusRequester = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                val isDown = keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN
                val isUp = keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_UP
                when (keyEvent.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_A -> {
                        if (isDown) engine.inputLeft = true
                        if (isUp) engine.inputLeft = false
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT,
                    KeyEvent.KEYCODE_D -> {
                        if (isDown) engine.inputRight = true
                        if (isUp) engine.inputRight = false
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_UP,
                    KeyEvent.KEYCODE_W,
                    KeyEvent.KEYCODE_SPACE -> {
                        if (isDown && !keyEvent.nativeKeyEvent.isCanceled) {
                            engine.inputJumpPressed = true
                        }
                        true
                    }
                    KeyEvent.KEYCODE_J,
                    KeyEvent.KEYCODE_Z,
                    KeyEvent.KEYCODE_ENTER -> {
                        if (isDown) engine.inputAttackPressed = true
                        true
                    }
                    KeyEvent.KEYCODE_K,
                    KeyEvent.KEYCODE_X -> {
                        if (isDown) engine.inputShurikenPressed = true
                        true
                    }
                    KeyEvent.KEYCODE_L,
                    KeyEvent.KEYCODE_C,
                    KeyEvent.KEYCODE_SHIFT_LEFT -> {
                        if (isDown) engine.inputDashPressed = true
                        true
                    }
                    else -> false
                }
            }
    ) {
        // --- 1. Game Canvas ---
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Read frameTick to trigger recomposition per frame
            @Suppress("UNUSED_VARIABLE") val tick = frameTick
            GameRenderer.render(this, engine, size.width, size.height)
        }

        // --- 2. Top HUD Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Left HUD: Health Hearts & Shurikens
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Hearts
                Row(
                    modifier = Modifier
                        .background(DarkCard.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val maxHp = engine.player.maxHealth
                    val currentHp = engine.player.health
                    for (i in 1..maxHp) {
                        Icon(
                            imageVector = if (i <= currentHp) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Heart",
                            tint = if (i <= currentHp) Crimson else TextMuted.copy(alpha = 0.5f),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Shurikens & Dash info
                Row(
                    modifier = Modifier
                        .background(DarkCard.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = MoonGlow,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "${engine.player.shurikens}/${engine.player.maxShurikens}",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Center: Chapter Title
            Text(
                text = engine.levelData.title.uppercase(),
                color = TextLight.copy(alpha = 0.85f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp,
                modifier = Modifier
                    .background(DarkCard.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            )

            // Right HUD: Scrolls, Coins, Pause Button
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Scrolls Found (3 slots)
                Row(
                    modifier = Modifier
                        .background(DarkCard.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val scrolls = engine.player.scrollsCollected
                    for (i in 1..3) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Scroll $i",
                            tint = if (i <= scrolls) StealthCyan else TextMuted.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Coins
                Row(
                    modifier = Modifier
                        .background(DarkCard.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Coins",
                        tint = NinjaGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${preferences.coins}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Pause Button
                IconButton(
                    onClick = { isPaused = true },
                    modifier = Modifier
                        .size(36.dp)
                        .background(DarkCard.copy(alpha = 0.8f), CircleShape)
                        .border(1.dp, TextMuted.copy(alpha = 0.4f), CircleShape)
                        .testTag("pause_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "Pause",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // --- 3. Boss Health Bar (if active) ---
        val boss = engine.enemies.firstOrNull { it.type == EnemyType.BOSS_KURO && it.health > 0 }
        if (boss != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 56.dp)
                    .width(320.dp)
                    .background(DarkCard.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                    .border(1.5.dp, ShadowRed, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (boss.bossPhase == 2) "LORD KURO [BLOOD RAGE]" else "LORD KURO - SHADOW WARLORD",
                            color = if (boss.bossPhase == 2) BloodMoon else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${boss.health.toInt()}/${boss.maxHealth.toInt()}",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (boss.health / boss.maxHealth).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (boss.bossPhase == 2) BloodMoon else Crimson,
                        trackColor = Obsidian
                    )
                }
            }
        }

        // --- 4. Touch Controls ---
        val dashCooldownRatio = (engine.player.dashCooldownTimer / preferences.getDashCooldown()).coerceIn(0f, 1f)
        GameTouchControls(
            modifier = Modifier.align(Alignment.BottomCenter),
            onLeftChange = { engine.inputLeft = it },
            onRightChange = { engine.inputRight = it },
            onJump = { engine.inputJumpPressed = true },
            onSlash = { engine.inputAttackPressed = true },
            onShuriken = { engine.inputShurikenPressed = true },
            onDash = { engine.inputDashPressed = true },
            shurikensCount = engine.player.shurikens,
            dashCooldownRatio = dashCooldownRatio
        )

        // --- 5. Dialogs ---
        if (isPaused) {
            PauseDialog(
                onResume = { isPaused = false },
                onRestart = {
                    isPaused = false
                    val lvl = LevelBuilder.buildLevel(currentLevelIdx)
                    engine = GameEngine(lvl, preferences, soundManager)
                },
                onExit = onBackToMenu,
                isSoundEnabled = soundEnabled,
                onToggleSound = {
                    soundEnabled = !soundEnabled
                    preferences.isSoundEnabled = soundEnabled
                    soundManager.isSoundEnabled = soundEnabled
                },
                isMusicEnabled = musicEnabled,
                onToggleMusic = {
                    musicEnabled = !musicEnabled
                    preferences.isMusicEnabled = musicEnabled
                    soundManager.isMusicEnabled = musicEnabled
                }
            )
        }

        if (engine.isGameOver) {
            GameOverDialog(
                onRestart = {
                    val lvl = LevelBuilder.buildLevel(currentLevelIdx)
                    engine = GameEngine(lvl, preferences, soundManager)
                },
                onExit = onBackToMenu
            )
        }

        if (engine.isVictory) {
            VictoryDialog(
                levelIndex = currentLevelIdx,
                coinsEarned = engine.player.coinsCollected,
                scrollsFound = engine.player.scrollsCollected,
                onNextLevel = {
                    if (currentLevelIdx < 4) {
                        currentLevelIdx++
                        val lvl = LevelBuilder.buildLevel(currentLevelIdx)
                        engine = GameEngine(lvl, preferences, soundManager)
                    } else {
                        onBackToMenu()
                    }
                },
                onRestart = {
                    val lvl = LevelBuilder.buildLevel(currentLevelIdx)
                    engine = GameEngine(lvl, preferences, soundManager)
                },
                onExit = onBackToMenu
            )
        }
    }
}
