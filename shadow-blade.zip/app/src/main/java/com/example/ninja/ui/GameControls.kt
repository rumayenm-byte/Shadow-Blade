package com.example.ninja.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun GameTouchControls(
    modifier: Modifier = Modifier,
    onLeftChange: (Boolean) -> Unit,
    onRightChange: (Boolean) -> Unit,
    onJump: () -> Unit,
    onSlash: () -> Unit,
    onShuriken: () -> Unit,
    onDash: () -> Unit,
    shurikensCount: Int,
    dashCooldownRatio: Float
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        // --- Left Cluster: Movement Buttons ---
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Move Left Button
            HoldableButton(
                icon = Icons.Default.ArrowBack,
                testTag = "btn_left",
                onStateChanged = onLeftChange
            )

            // Move Right Button
            HoldableButton(
                icon = Icons.Default.ArrowForward,
                testTag = "btn_right",
                onStateChanged = onRightChange
            )
        }

        // --- Right Cluster: Combat & Acrobatics ---
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Shadow Dash Button
            GameActionButton(
                icon = Icons.Default.FlashOn,
                testTag = "btn_dash",
                size = 58.dp,
                iconSize = 28.dp,
                containerColor = if (dashCooldownRatio <= 0f) DarkCard else Obsidian,
                borderColor = if (dashCooldownRatio <= 0f) StealthCyan else TextMuted.copy(alpha = 0.4f),
                iconColor = if (dashCooldownRatio <= 0f) StealthCyan else TextMuted,
                onClick = {
                    if (dashCooldownRatio <= 0f) onDash()
                }
            )

            // Shuriken Throw Button
            BadgedBox(
                badge = {
                    Badge(
                        containerColor = Crimson,
                        contentColor = Color.White
                    ) {
                        Text(
                            text = "$shurikensCount",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            ) {
                GameActionButton(
                    icon = Icons.Default.Stars,
                    testTag = "btn_shuriken",
                    size = 58.dp,
                    iconSize = 28.dp,
                    containerColor = DarkCard,
                    borderColor = if (shurikensCount > 0) MoonGlow else TextMuted.copy(alpha = 0.4f),
                    iconColor = if (shurikensCount > 0) MoonGlow else TextMuted,
                    onClick = onShuriken
                )
            }

            // Katana Slash Button (Primary attack)
            GameActionButton(
                icon = Icons.Default.Hardware, // Cleaver/Sword symbol
                testTag = "btn_attack",
                size = 76.dp,
                iconSize = 40.dp,
                containerColor = Color(0xFF8B0000),
                pressedColor = Color(0xFFFF1744),
                borderColor = Crimson,
                iconColor = Color.White,
                onClick = onSlash
            )

            // Jump Button
            GameActionButton(
                icon = Icons.Default.ArrowUpward,
                testTag = "btn_jump",
                size = 76.dp,
                iconSize = 40.dp,
                containerColor = DarkCard,
                pressedColor = StealthCyan.copy(alpha = 0.35f),
                borderColor = StealthCyan,
                iconColor = StealthCyan,
                onClick = onJump
            )
        }
    }
}

/**
 * Holdable virtual controller button for continuous movement (Left/Right).
 * Uses direct pointer event tracking with multitouch isolation and zero gesture cancellation on motion.
 */
@Composable
private fun HoldableButton(
    icon: ImageVector,
    testTag: String,
    onStateChanged: (Boolean) -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val currentOnStateChanged by rememberUpdatedState(onStateChanged)

    Box(
        modifier = Modifier
            .size(74.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isPressed) Crimson.copy(alpha = 0.45f) else DarkCard.copy(alpha = 0.85f))
            .border(
                2.5.dp,
                if (isPressed) Crimson else TextMuted.copy(alpha = 0.6f),
                RoundedCornerShape(20.dp)
            )
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isPressed = true
                    currentOnStateChanged(true)

                    var pointerActive = true
                    while (pointerActive) {
                        val event = awaitPointerEvent()
                        val currentPointer = event.changes.firstOrNull { it.id == down.id }
                        if (currentPointer == null || !currentPointer.pressed) {
                            pointerActive = false
                        } else {
                            currentPointer.consume()
                        }
                    }

                    isPressed = false
                    currentOnStateChanged(false)
                }
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isPressed) Crimson else Color.White,
            modifier = Modifier.size(36.dp)
        )
    }
}

/**
 * Instant Action Button (Jump, Attack, Shuriken, Dash).
 * Fires immediately on down touch with zero latency and full multitouch isolation.
 */
@Composable
private fun GameActionButton(
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 74.dp,
    iconSize: Dp = 38.dp,
    containerColor: Color = DarkCard,
    pressedColor: Color = Crimson,
    borderColor: Color = StealthCyan,
    iconColor: Color = Color.White
) {
    var isPressed by remember { mutableStateOf(false) }
    val currentOnClick by rememberUpdatedState(onClick)

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(if (isPressed) pressedColor else containerColor.copy(alpha = 0.9f))
            .border(3.dp, if (isPressed) Color.White else borderColor, CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    isPressed = true
                    currentOnClick()

                    var pointerActive = true
                    while (pointerActive) {
                        val event = awaitPointerEvent()
                        val currentPointer = event.changes.firstOrNull { it.id == down.id }
                        if (currentPointer == null || !currentPointer.pressed) {
                            pointerActive = false
                        } else {
                            currentPointer.consume()
                        }
                    }

                    isPressed = false
                }
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isPressed) Color.White else iconColor,
            modifier = Modifier.size(iconSize)
        )
    }
}
