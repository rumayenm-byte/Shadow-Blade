package com.example.ninja.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun PauseDialog(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExit: () -> Unit,
    isSoundEnabled: Boolean,
    onToggleSound: () -> Unit,
    isMusicEnabled: Boolean,
    onToggleMusic: () -> Unit
) {
    Dialog(onDismissRequest = onResume) {
        Box(
            modifier = Modifier
                .width(360.dp)
                .background(
                    brush = Brush.verticalGradient(listOf(DarkSurface, Obsidian)),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(2.dp, Crimson.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "GAME PAUSED",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = onToggleSound,
                        modifier = Modifier
                            .background(DarkCard, RoundedCornerShape(8.dp))
                            .border(1.dp, TextMuted.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Toggle SFX",
                            tint = if (isSoundEnabled) StealthCyan else TextMuted
                        )
                    }

                    IconButton(
                        onClick = onToggleMusic,
                        modifier = Modifier
                            .background(DarkCard, RoundedCornerShape(8.dp))
                            .border(1.dp, TextMuted.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = if (isMusicEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                            contentDescription = "Toggle Music",
                            tint = if (isMusicEnabled) Crimson else TextMuted
                        )
                    }
                }

                Button(
                    onClick = onResume,
                    modifier = Modifier.fillMaxWidth().testTag("resume_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Crimson)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("RESUME", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier.fillMaxWidth().testTag("restart_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("RESTART", fontWeight = FontWeight.Bold)
                }

                TextButton(
                    onClick = onExit,
                    modifier = Modifier.testTag("exit_to_menu_button")
                ) {
                    Text("MAIN MENU", color = TextMuted)
                }
            }
        }
    }
}

@Composable
fun GameOverDialog(
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(onDismissRequest = {}) {
        Box(
            modifier = Modifier
                .width(360.dp)
                .background(
                    brush = Brush.verticalGradient(listOf(Color(0xFF26050A), Obsidian)),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(2.dp, ShadowRed, RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "YOU HAVE FALLEN",
                    color = BloodMoon,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "The shadows claim your soul. Rise again, Shinobi.",
                    color = TextMuted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Button(
                    onClick = onRestart,
                    modifier = Modifier.fillMaxWidth().testTag("retry_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Crimson)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("TRY AGAIN", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onExit,
                    modifier = Modifier.fillMaxWidth().testTag("game_over_menu_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Text("MAIN MENU")
                }
            }
        }
    }
}

@Composable
fun VictoryDialog(
    levelIndex: Int,
    coinsEarned: Int,
    scrollsFound: Int,
    onNextLevel: () -> Unit,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(onDismissRequest = {}) {
        Box(
            modifier = Modifier
                .width(380.dp)
                .background(
                    brush = Brush.verticalGradient(listOf(DarkSurface, Obsidian)),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(2.dp, NinjaGold.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (levelIndex == 4) "WARLORD VANQUISHED!" else "STAGE CLEARED!",
                    color = NinjaGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )

                // Stars display (1 to 3)
                val stars = 1 + (if (scrollsFound >= 2) 1 else 0) + (if (scrollsFound >= 3) 1 else 0)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (i in 1..3) {
                        Icon(
                            imageVector = if (i <= stars) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = if (i <= stars) NinjaGold else TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                // Stats row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkCard, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NinjaGold, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("+$coinsEarned Gold", color = Color.White, fontSize = 14.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = StealthCyan, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("$scrollsFound/3 Scrolls", color = Color.White, fontSize = 14.sp)
                    }
                }

                if (levelIndex < 4) {
                    Button(
                        onClick = onNextLevel,
                        modifier = Modifier.fillMaxWidth().testTag("next_level_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Crimson)
                    ) {
                        Text("NEXT CHAPTER", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onRestart,
                        modifier = Modifier.weight(1f).testTag("replay_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("REPLAY")
                    }
                    OutlinedButton(
                        onClick = onExit,
                        modifier = Modifier.weight(1f).testTag("victory_menu_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("MENU")
                    }
                }
            }
        }
    }
}
