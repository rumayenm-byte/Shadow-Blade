package com.example.ninja.engine

import com.example.ninja.model.*

object LevelBuilder {

    fun buildLevel(levelIndex: Int): LevelData {
        return when (levelIndex) {
            1 -> buildLevel1()
            2 -> buildLevel2()
            3 -> buildLevel3()
            4 -> buildLevel4()
            else -> buildLevel1()
        }
    }

    private fun buildLevel1(): LevelData {
        val width = 3600f
        val height = 900f
        val groundY = 720f

        val platforms = mutableListOf<Platform>()
        // Ground sections with gaps
        platforms.add(Platform(0f, groundY, 700f, 180f))
        // Gap 700..850 (spike pit below)
        platforms.add(Platform(850f, groundY, 750f, 180f))
        // Gap 1600..1800 (chasm)
        platforms.add(Platform(1800f, groundY, 900f, 180f))
        // Gap 2700..2900 (spikes)
        platforms.add(Platform(2900f, groundY, 700f, 180f))

        // Elevated bamboo platforms
        platforms.add(Platform(300f, 570f, 220f, 24f, isBamboo = true))
        platforms.add(Platform(650f, 460f, 200f, 24f, isBamboo = true))
        platforms.add(Platform(950f, 540f, 240f, 24f, isBamboo = true))
        platforms.add(Platform(1250f, 430f, 260f, 24f, isBamboo = true))
        platforms.add(Platform(1600f, 480f, 160f, 24f, isBamboo = true))

        // High secret branch with Scroll #2
        platforms.add(Platform(1150f, 280f, 200f, 24f, isBamboo = true))

        // Upper pathway over second pit
        platforms.add(Platform(1950f, 550f, 220f, 24f, isBamboo = true))
        platforms.add(Platform(2250f, 440f, 240f, 24f, isBamboo = true))
        platforms.add(Platform(2550f, 520f, 220f, 24f, isBamboo = true))

        // Wall jump vertical shafts
        platforms.add(Platform(2800f, 320f, 30f, 400f))
        platforms.add(Platform(2950f, 320f, 30f, 400f))
        platforms.add(Platform(2800f, 300f, 180f, 24f))

        // Traps
        val traps = mutableListOf<Trap>()
        // Pit 1 spikes
        traps.add(Trap(1, TrapType.SPIKE_PIT, 700f, groundY + 120f, 150f, 60f))
        // High swinging mace
        traps.add(
            Trap(
                id = 2,
                type = TrapType.SWINGING_MACE,
                x = 1400f,
                y = 450f,
                width = 36f,
                height = 36f,
                pivotX = 1400f,
                pivotY = 220f,
                chainLength = 170f,
                swingSpeed = 2.4f
            )
        )
        // Pit 2 spikes
        traps.add(Trap(3, TrapType.SPIKE_PIT, 2700f, groundY + 120f, 200f, 60f))
        // Ground spike hazard
        traps.add(Trap(4, TrapType.SPIKE_PIT, 1100f, groundY - 10f, 60f, 20f))

        // Enemies
        val enemies = mutableListOf<Enemy>()
        enemies.add(
            Enemy(
                id = 1,
                type = EnemyType.ASHIGARU,
                x = 550f,
                y = groundY,
                patrolMinX = 350f,
                patrolMaxX = 680f,
                health = 35f,
                maxHealth = 35f
            )
        )
        enemies.add(
            Enemy(
                id = 2,
                type = EnemyType.ASHIGARU,
                x = 1100f,
                y = groundY,
                patrolMinX = 900f,
                patrolMaxX = 1500f,
                health = 35f,
                maxHealth = 35f
            )
        )
        enemies.add(
            Enemy(
                id = 3,
                type = EnemyType.ARCHER,
                x = 1350f,
                y = 430f,
                patrolMinX = 1300f,
                patrolMaxX = 1450f,
                health = 25f,
                maxHealth = 25f,
                facingRight = false
            )
        )
        enemies.add(
            Enemy(
                id = 4,
                type = EnemyType.ASHIGARU,
                x = 2100f,
                y = groundY,
                patrolMinX = 1850f,
                patrolMaxX = 2300f,
                health = 35f,
                maxHealth = 35f
            )
        )
        enemies.add(
            Enemy(
                id = 5,
                type = EnemyType.ASSASSIN,
                x = 3100f,
                y = groundY,
                patrolMinX = 2950f,
                patrolMaxX = 3350f,
                health = 50f,
                maxHealth = 50f
            )
        )

        // Collectibles
        val collectibles = mutableListOf<Collectible>()
        // Coins
        var coinId = 1
        listOf(
            350f to 520f, 400f to 520f, 450f to 520f,
            700f to 410f, 750f to 410f,
            1000f to 490f, 1050f to 490f,
            1300f to 380f, 1350f to 380f,
            2000f to 500f, 2050f to 500f,
            2300f to 390f, 2350f to 390f,
            3050f to 660f, 3150f to 660f, 3250f to 660f
        ).forEach { (cx, cy) ->
            collectibles.add(Collectible(coinId++, CollectibleType.COIN, cx, cy))
        }

        // 3 Shinobi Scrolls (Level 1)
        collectibles.add(Collectible(coinId++, CollectibleType.SCROLL, 400f, 380f))
        collectibles.add(Collectible(coinId++, CollectibleType.SCROLL, 1250f, 230f))
        collectibles.add(Collectible(coinId++, CollectibleType.SCROLL, 2875f, 250f))

        // Heart pickup
        collectibles.add(Collectible(coinId++, CollectibleType.HEART, 1750f, 430f))

        // Checkpoints
        val checkpoints = listOf(
            Checkpoint(1550f, groundY)
        )

        return LevelData(
            id = 1,
            title = "Whispering Bamboo",
            subtitle = "Chapter I - The Path of Solitude",
            width = width,
            height = height,
            spawnX = 120f,
            spawnY = groundY - 20f,
            portal = Portal(3450f, groundY),
            platforms = platforms,
            traps = traps,
            enemies = enemies,
            collectibles = collectibles,
            checkpoints = checkpoints,
            theme = BackgroundTheme.BAMBOO_MOON
        )
    }

    private fun buildLevel2(): LevelData {
        val width = 4000f
        val height = 950f
        val groundY = 740f

        val platforms = mutableListOf<Platform>()
        platforms.add(Platform(0f, groundY, 650f, 200f))
        platforms.add(Platform(800f, groundY, 700f, 200f))
        platforms.add(Platform(1750f, groundY, 800f, 200f))
        platforms.add(Platform(2800f, groundY, 1200f, 200f))

        // Pagoda rooftops & bridges
        platforms.add(Platform(300f, 580f, 220f, 28f))
        platforms.add(Platform(600f, 470f, 250f, 28f))
        platforms.add(Platform(950f, 400f, 260f, 28f))
        platforms.add(Platform(1300f, 480f, 220f, 28f))
        platforms.add(Platform(1600f, 560f, 180f, 28f))

        // High temple bell tower
        platforms.add(Platform(850f, 240f, 240f, 28f))

        // Mid section floating pillars
        platforms.add(Platform(1950f, 580f, 180f, 28f))
        platforms.add(Platform(2200f, 460f, 200f, 28f))
        platforms.add(Platform(2500f, 380f, 240f, 28f))

        // High pagoda rafters
        platforms.add(Platform(2900f, 520f, 260f, 28f))
        platforms.add(Platform(3250f, 420f, 240f, 28f))
        platforms.add(Platform(3600f, 550f, 200f, 28f))

        // Traps: Spinning saws & Swinging pendulums
        val traps = mutableListOf<Trap>()
        // Gap 1 spikes
        traps.add(Trap(1, TrapType.SPIKE_PIT, 650f, groundY + 120f, 150f, 60f))
        // Gap 2 spikes
        traps.add(Trap(2, TrapType.SPIKE_PIT, 1500f, groundY + 120f, 250f, 60f))
        // Gap 3 spikes
        traps.add(Trap(3, TrapType.SPIKE_PIT, 2550f, groundY + 120f, 250f, 60f))

        // Moving saw blade on rooftop
        traps.add(
            Trap(
                id = 4,
                type = TrapType.SPINNING_SAW,
                x = 1000f,
                y = 385f,
                width = 38f,
                height = 38f,
                minX = 960f,
                maxX = 1200f,
                speed = 110f
            )
        )

        // Swinging spiked mace 1
        traps.add(
            Trap(
                id = 5,
                type = TrapType.SWINGING_MACE,
                x = 750f,
                y = 380f,
                width = 40f,
                height = 40f,
                pivotX = 750f,
                pivotY = 160f,
                chainLength = 190f,
                swingSpeed = 2.6f
            )
        )

        // Swinging spiked mace 2
        traps.add(
            Trap(
                id = 6,
                type = TrapType.SWINGING_MACE,
                x = 2350f,
                y = 400f,
                width = 40f,
                height = 40f,
                pivotX = 2350f,
                pivotY = 180f,
                chainLength = 180f,
                swingSpeed = 2.8f
            )
        )

        // Enemies
        val enemies = mutableListOf<Enemy>()
        enemies.add(
            Enemy(
                id = 1,
                type = EnemyType.ASHIGARU,
                x = 450f,
                y = groundY,
                patrolMinX = 250f,
                patrolMaxX = 620f
            )
        )
        enemies.add(
            Enemy(
                id = 2,
                type = EnemyType.ARCHER,
                x = 720f,
                y = 470f,
                patrolMinX = 650f,
                patrolMaxX = 780f,
                facingRight = false
            )
        )
        enemies.add(
            Enemy(
                id = 3,
                type = EnemyType.SHIELD_BRUTE,
                x = 1150f,
                y = groundY,
                patrolMinX = 900f,
                patrolMaxX = 1450f,
                health = 70f,
                maxHealth = 70f
            )
        )
        enemies.add(
            Enemy(
                id = 4,
                type = EnemyType.ARCHER,
                x = 2300f,
                y = 460f,
                patrolMinX = 2220f,
                patrolMaxX = 2380f,
                facingRight = false
            )
        )
        enemies.add(
            Enemy(
                id = 5,
                type = EnemyType.ASSASSIN,
                x = 2050f,
                y = groundY,
                patrolMinX = 1850f,
                patrolMaxX = 2450f,
                health = 55f,
                maxHealth = 55f
            )
        )
        enemies.add(
            Enemy(
                id = 6,
                type = EnemyType.ASHIGARU,
                x = 3100f,
                y = groundY,
                patrolMinX = 2850f,
                patrolMaxX = 3300f
            )
        )
        enemies.add(
            Enemy(
                id = 7,
                type = EnemyType.SHIELD_BRUTE,
                x = 3500f,
                y = groundY,
                patrolMinX = 3350f,
                patrolMaxX = 3800f,
                health = 75f,
                maxHealth = 75f
            )
        )

        // Collectibles
        val collectibles = mutableListOf<Collectible>()
        var cid = 1
        listOf(
            350f to 530f, 650f to 420f,
            1350f to 430f, 1650f to 510f,
            2000f to 530f, 2250f to 410f,
            2950f to 470f, 3300f to 370f,
            3650f to 500f, 3050f to 690f, 3350f to 690f
        ).forEach { (cx, cy) ->
            collectibles.add(Collectible(cid++, CollectibleType.COIN, cx, cy))
        }

        // 3 Shinobi Scrolls (Level 2)
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 970f, 180f))
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 2620f, 320f))
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 3700f, 490f))

        // Hearts
        collectibles.add(Collectible(cid++, CollectibleType.HEART, 1780f, 700f))

        // Checkpoints
        val checkpoints = listOf(
            Checkpoint(1780f, groundY)
        )

        return LevelData(
            id = 2,
            title = "Crimson Shrine",
            subtitle = "Chapter II - Blood on the Rooftops",
            width = width,
            height = height,
            spawnX = 120f,
            spawnY = groundY - 20f,
            portal = Portal(3880f, groundY),
            platforms = platforms,
            traps = traps,
            enemies = enemies,
            collectibles = collectibles,
            checkpoints = checkpoints,
            theme = BackgroundTheme.CRIMSON_SUNSET
        )
    }

    private fun buildLevel3(): LevelData {
        val width = 4200f
        val height = 1000f
        val groundY = 760f

        val platforms = mutableListOf<Platform>()
        platforms.add(Platform(0f, groundY, 600f, 240f))
        // Huge toxic spike ravine with narrow stone pillars
        platforms.add(Platform(750f, 600f, 140f, 26f))
        platforms.add(Platform(1050f, 480f, 150f, 26f))
        platforms.add(Platform(1350f, 370f, 160f, 26f))
        platforms.add(Platform(1650f, 500f, 150f, 26f))
        platforms.add(Platform(1950f, groundY, 650f, 240f))

        // Castle wall climb (vertical shafts)
        platforms.add(Platform(2700f, 350f, 35f, 420f))
        platforms.add(Platform(2880f, 350f, 35f, 420f))
        platforms.add(Platform(2650f, 330f, 300f, 26f))

        // Upper castle battlements
        platforms.add(Platform(3050f, 420f, 260f, 26f))
        platforms.add(Platform(3400f, 520f, 240f, 26f))
        platforms.add(Platform(3700f, groundY, 500f, 240f))

        val traps = mutableListOf<Trap>()
        // Spikes across bottom ravine
        traps.add(Trap(1, TrapType.SPIKE_PIT, 600f, groundY + 80f, 1350f, 100f))

        // Dart shooters on fortress walls
        traps.add(
            Trap(
                id = 2,
                type = TrapType.DART_SHOOTER,
                x = 1030f,
                y = 460f,
                width = 24f,
                height = 24f,
                fireCooldown = 2.2f,
                direction = -1f
            )
        )
        traps.add(
            Trap(
                id = 3,
                type = TrapType.DART_SHOOTER,
                x = 1330f,
                y = 350f,
                width = 24f,
                height = 24f,
                fireCooldown = 1.8f,
                direction = 1f
            )
        )

        // Spinning saw in shaft
        traps.add(
            Trap(
                id = 4,
                type = TrapType.SPINNING_SAW,
                x = 2790f,
                y = 520f,
                width = 42f,
                height = 42f,
                minX = 2740f,
                maxX = 2840f,
                speed = 90f
            )
        )

        // Swinging mace on battlements
        traps.add(
            Trap(
                id = 5,
                type = TrapType.SWINGING_MACE,
                x = 3220f,
                y = 360f,
                width = 44f,
                height = 44f,
                pivotX = 3220f,
                pivotY = 160f,
                chainLength = 190f,
                swingSpeed = 2.9f
            )
        )

        // Enemies
        val enemies = mutableListOf<Enemy>()
        enemies.add(
            Enemy(
                id = 1,
                type = EnemyType.ASSASSIN,
                x = 450f,
                y = groundY,
                patrolMinX = 250f,
                patrolMaxX = 580f,
                health = 50f,
                maxHealth = 50f
            )
        )
        enemies.add(
            Enemy(
                id = 2,
                type = EnemyType.ARCHER,
                x = 1420f,
                y = 370f,
                patrolMinX = 1380f,
                patrolMaxX = 1480f,
                facingRight = false
            )
        )
        enemies.add(
            Enemy(
                id = 3,
                type = EnemyType.SHIELD_BRUTE,
                x = 2200f,
                y = groundY,
                patrolMinX = 2000f,
                patrolMaxX = 2550f,
                health = 80f,
                maxHealth = 80f
            )
        )
        enemies.add(
            Enemy(
                id = 4,
                type = EnemyType.ASSASSIN,
                x = 2400f,
                y = groundY,
                patrolMinX = 2100f,
                patrolMaxX = 2580f,
                health = 60f,
                maxHealth = 60f
            )
        )
        enemies.add(
            Enemy(
                id = 5,
                type = EnemyType.ARCHER,
                x = 3180f,
                y = 420f,
                patrolMinX = 3100f,
                patrolMaxX = 3260f,
                facingRight = false
            )
        )
        enemies.add(
            Enemy(
                id = 6,
                type = EnemyType.SHIELD_BRUTE,
                x = 3900f,
                y = groundY,
                patrolMinX = 3750f,
                patrolMaxX = 4100f,
                health = 85f,
                maxHealth = 85f
            )
        )

        val collectibles = mutableListOf<Collectible>()
        var cid = 1
        listOf(
            820f to 550f, 1120f to 430f, 1420f to 320f,
            1720f to 450f, 2100f to 710f, 2300f to 710f,
            3150f to 370f, 3500f to 470f, 3850f to 710f
        ).forEach { (cx, cy) ->
            collectibles.add(Collectible(cid++, CollectibleType.COIN, cx, cy))
        }

        // 3 Scrolls (Level 3)
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 1370f, 300f))
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 2800f, 280f))
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 3520f, 440f))

        collectibles.add(Collectible(cid++, CollectibleType.HEART, 1980f, groundY - 20f))

        val checkpoints = listOf(
            Checkpoint(2000f, groundY)
        )

        return LevelData(
            id = 3,
            title = "Shadow Fortress",
            subtitle = "Chapter III - Into the Tiger's Den",
            width = width,
            height = height,
            spawnX = 120f,
            spawnY = groundY - 20f,
            portal = Portal(4080f, groundY),
            platforms = platforms,
            traps = traps,
            enemies = enemies,
            collectibles = collectibles,
            checkpoints = checkpoints,
            theme = BackgroundTheme.SHADOW_FORTRESS
        )
    }

    private fun buildLevel4(): LevelData {
        // Epic Boss Arena: Lord Kuro
        val width = 2400f
        val height = 900f
        val groundY = 720f

        val platforms = mutableListOf<Platform>()
        // Solid battle arena floor
        platforms.add(Platform(0f, groundY, width, 180f))

        // Left and right arena boundary walls
        platforms.add(Platform(0f, 0f, 40f, height))
        platforms.add(Platform(width - 40f, 0f, 40f, height))

        // Tactical ninja platforms for dodging boss ground shockwaves and plunging attacks
        platforms.add(Platform(220f, 540f, 220f, 24f))
        platforms.add(Platform(540f, 410f, 200f, 24f))
        platforms.add(Platform(1050f, 350f, 300f, 24f)) // Central high shrine platform
        platforms.add(Platform(1660f, 410f, 200f, 24f))
        platforms.add(Platform(1960f, 540f, 220f, 24f))

        val traps = mutableListOf<Trap>()
        // Spikes on extreme corners
        traps.add(Trap(1, TrapType.SPIKE_PIT, 40f, groundY - 10f, 60f, 20f))
        traps.add(Trap(2, TrapType.SPIKE_PIT, width - 100f, groundY - 10f, 60f, 20f))

        // The Boss: Lord Kuro!
        val enemies = mutableListOf<Enemy>()
        val bossKuro = Enemy(
            id = 100,
            type = EnemyType.BOSS_KURO,
            x = 1600f,
            y = groundY,
            width = 68f,
            height = 96f,
            patrolMinX = 300f,
            patrolMaxX = 2100f,
            facingRight = false,
            health = 320f,
            maxHealth = 320f,
            isBoss = true,
            attackCooldown = 1.8f
        )
        enemies.add(bossKuro)

        val collectibles = mutableListOf<Collectible>()
        var cid = 1
        listOf(
            300f to 490f, 600f to 360f, 1200f to 300f, 1750f to 360f, 2050f to 490f
        ).forEach { (cx, cy) ->
            collectibles.add(Collectible(cid++, CollectibleType.COIN, cx, cy))
        }

        // Scrolls in boss arena
        collectibles.add(Collectible(cid++, CollectibleType.SCROLL, 1200f, 220f))
        collectibles.add(Collectible(cid++, CollectibleType.HEART, 640f, 360f))
        collectibles.add(Collectible(cid++, CollectibleType.HEART, 1760f, 360f))

        return LevelData(
            id = 4,
            title = "Warlord's Throne",
            subtitle = "Final Showdown - Lord Kuro",
            width = width,
            height = height,
            spawnX = 180f,
            spawnY = groundY - 20f,
            portal = Portal(width - 160f, groundY),
            platforms = platforms,
            traps = traps,
            enemies = enemies,
            collectibles = collectibles,
            checkpoints = listOf(Checkpoint(180f, groundY)),
            theme = BackgroundTheme.ECLIPSE_BLOOD_MOON
        )
    }
}
