package com.example.ninja.data

import android.content.Context
import android.content.SharedPreferences

class GamePreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ninja_arashi_save", Context.MODE_PRIVATE)

    var unlockedLevel: Int
        get() = prefs.getInt(KEY_UNLOCKED_LEVEL, 1)
        set(value) = prefs.edit().putInt(KEY_UNLOCKED_LEVEL, value).apply()

    var coins: Int
        get() = prefs.getInt(KEY_COINS, 50) // start with 50 gold as starter gift!
        set(value) = prefs.edit().putInt(KEY_COINS, value).apply()

    var healthLevel: Int
        get() = prefs.getInt(KEY_HEALTH_LEVEL, 0)
        set(value) = prefs.edit().putInt(KEY_HEALTH_LEVEL, value).apply()

    var damageLevel: Int
        get() = prefs.getInt(KEY_DAMAGE_LEVEL, 0)
        set(value) = prefs.edit().putInt(KEY_DAMAGE_LEVEL, value).apply()

    var shurikensLevel: Int
        get() = prefs.getInt(KEY_SHURIKEN_LEVEL, 0)
        set(value) = prefs.edit().putInt(KEY_SHURIKEN_LEVEL, value).apply()

    var shurikenLevel: Int
        get() = shurikensLevel
        set(value) { shurikensLevel = value }

    var dashLevel: Int
        get() = prefs.getInt(KEY_DASH_LEVEL, 0)
        set(value) = prefs.edit().putInt(KEY_DASH_LEVEL, value).apply()

    var isSoundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var isMusicEnabled: Boolean
        get() = prefs.getBoolean(KEY_MUSIC_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_MUSIC_ENABLED, value).apply()

    var isHapticsEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTICS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTICS_ENABLED, value).apply()

    fun getLevelStars(levelIndex: Int): Int {
        return prefs.getInt("stars_level_$levelIndex", 0)
    }

    fun setLevelStars(levelIndex: Int, stars: Int) {
        val current = getLevelStars(levelIndex)
        if (stars > current) {
            prefs.edit().putInt("stars_level_$levelIndex", stars).apply()
        }
    }

    fun isScrollFound(levelIndex: Int, scrollIndex: Int): Boolean {
        return prefs.getBoolean("scroll_${levelIndex}_$scrollIndex", false)
    }

    fun setScrollFound(levelIndex: Int, scrollIndex: Int) {
        prefs.edit().putBoolean("scroll_${levelIndex}_$scrollIndex", true).apply()
    }

    // Upgrade costs and stats calculation
    fun getUpgradeCost(level: Int): Int {
        return when (level) {
            0 -> 100
            1 -> 250
            2 -> 500
            else -> 1000
        }
    }

    fun getMaxHealth(): Int = 3 + healthLevel // 3 to 6
    fun getKatanaDamage(): Float = 25f * (1f + damageLevel * 0.35f) // 25 to 51
    fun getMaxShurikens(): Int = 5 + shurikensLevel * 2 // 5 to 11
    fun getDashCooldown(): Float = 2.0f - dashLevel * 0.35f // 2.0s down to 0.95s

    companion object {
        private const val KEY_UNLOCKED_LEVEL = "unlocked_level"
        private const val KEY_COINS = "coins"
        private const val KEY_HEALTH_LEVEL = "health_level"
        private const val KEY_DAMAGE_LEVEL = "damage_level"
        private const val KEY_SHURIKEN_LEVEL = "shuriken_level"
        private const val KEY_DASH_LEVEL = "dash_level"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_MUSIC_ENABLED = "music_enabled"
        private const val KEY_HAPTICS_ENABLED = "haptics_enabled"
    }
}
