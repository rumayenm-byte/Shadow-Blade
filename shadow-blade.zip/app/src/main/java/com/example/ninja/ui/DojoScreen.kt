package com.example.ninja.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ui.theme.*

data class UpgradeItem(
    val id: String,
    val name: String,
    val description: String,
    val icon: ImageVector,
    val currentTier: Int,
    val maxTier: Int = 3,
    val cost: Int,
    val onUpgrade: () -> Unit
)

@Composable
fun DojoScreen(
    preferences: GamePreferences,
    soundManager: SoundManager,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var coins by remember { mutableIntStateOf(preferences.coins) }
    var healthLvl by remember { mutableIntStateOf(preferences.healthLevel) }
    var damageLvl by remember { mutableIntStateOf(preferences.damageLevel) }
    var shurikensLvl by remember { mutableIntStateOf(preferences.shurikensLevel) }
    var dashLvl by remember { mutableIntStateOf(preferences.dashLevel) }

    val upgrades = listOf(
        UpgradeItem(
            id = "vitality",
            name = "Vitality (Heart of Arashi)",
            description = "Increases max vitality (+1 Heart container). Current: ${3 + healthLvl} Hearts.",
            icon = Icons.Default.Favorite,
            currentTier = healthLvl,
            cost = preferences.getUpgradeCost(healthLvl),
            onUpgrade = {
                val cost = preferences.getUpgradeCost(healthLvl)
                if (coins >= cost && healthLvl < 3) {
                    preferences.coins -= cost
                    preferences.healthLevel = healthLvl + 1
                    coins = preferences.coins
                    healthLvl = preferences.healthLevel
                    soundManager.playSound(SoundManager.SoundType.CHECKPOINT)
                    soundManager.triggerHaptic(30, 160)
                }
            }
        ),
        UpgradeItem(
            id = "katana",
            name = "Muramasa Katana Mastery",
            description = "Hones the edge of your blade (+35% slash damage). Slices through armor.",
            icon = Icons.Default.Hardware,
            currentTier = damageLvl,
            cost = preferences.getUpgradeCost(damageLvl),
            onUpgrade = {
                val cost = preferences.getUpgradeCost(damageLvl)
                if (coins >= cost && damageLvl < 3) {
                    preferences.coins -= cost
                    preferences.damageLevel = damageLvl + 1
                    coins = preferences.coins
                    damageLvl = preferences.damageLevel
                    soundManager.playSound(SoundManager.SoundType.SLASH)
                    soundManager.triggerHaptic(30, 160)
                }
            }
        ),
        UpgradeItem(
            id = "shurikens",
            name = "Storm of Shurikens",
            description = "Carries more throwing stars (+2 Shurikens). Current: ${5 + shurikensLvl * 2} max.",
            icon = Icons.Default.Stars,
            currentTier = shurikensLvl,
            cost = preferences.getUpgradeCost(shurikensLvl),
            onUpgrade = {
                val cost = preferences.getUpgradeCost(shurikensLvl)
                if (coins >= cost && shurikensLvl < 3) {
                    preferences.coins -= cost
                    preferences.shurikenLevel = shurikensLvl + 1
                    coins = preferences.coins
                    shurikensLvl = preferences.shurikenLevel
                    soundManager.playSound(SoundManager.SoundType.SHURIKEN)
                    soundManager.triggerHaptic(30, 160)
                }
            }
        ),
        UpgradeItem(
            id = "dash",
            name = "Phantom Shadow Step",
            description = "Reduces dash cooldown and extends invulnerability frames.",
            icon = Icons.Default.FlashOn,
            currentTier = dashLvl,
            cost = preferences.getUpgradeCost(dashLvl),
            onUpgrade = {
                val cost = preferences.getUpgradeCost(dashLvl)
                if (coins >= cost && dashLvl < 3) {
                    preferences.coins -= cost
                    preferences.dashLevel = dashLvl + 1
                    coins = preferences.coins
                    dashLvl = preferences.dashLevel
                    soundManager.playSound(SoundManager.SoundType.DASH)
                    soundManager.triggerHaptic(30, 160)
                }
            }
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Obsidian)
            .padding(horizontal = 24.dp, vertical = 18.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .background(DarkCard, CircleShape)
                            .border(1.dp, TextMuted.copy(alpha = 0.4f), CircleShape)
                            .testTag("dojo_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = "DOJO OF ARASHI",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }

                // Coins
                Row(
                    modifier = Modifier
                        .background(DarkCard, RoundedCornerShape(12.dp))
                        .border(1.dp, NinjaGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NinjaGold, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("$coins Gold", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Grid of 4 Upgrades
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(upgrades.size) { index ->
                    val item = upgrades[index]
                    val isMax = item.currentTier >= item.maxTier
                    val canAfford = coins >= item.cost && !isMax

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                brush = Brush.verticalGradient(listOf(DarkSurface, DarkCard))
                            )
                            .border(1.dp, if (canAfford) Crimson.copy(alpha = 0.6f) else TextMuted.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = null,
                                        tint = if (item.id == "vitality") Crimson else if (item.id == "dash") StealthCyan else NinjaGold,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = item.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Level Pips
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    for (t in 1..item.maxTier) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(if (t <= item.currentTier) NinjaGold else TextMuted.copy(alpha = 0.3f))
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(6.dp))

                            Text(
                                text = item.description,
                                color = TextMuted,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            Spacer(Modifier.height(10.dp))

                            Button(
                                onClick = item.onUpgrade,
                                enabled = canAfford,
                                modifier = Modifier.fillMaxWidth().testTag("upgrade_${item.id}"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (canAfford) Crimson else DarkCard,
                                    disabledContainerColor = DarkCard.copy(alpha = 0.5f),
                                    disabledContentColor = TextMuted.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                if (isMax) {
                                    Text("MAX TIER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NinjaGold)
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = NinjaGold, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("${item.cost} GOLD", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
