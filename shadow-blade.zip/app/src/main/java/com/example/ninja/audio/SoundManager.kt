package com.example.ninja.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.sin

/**
 * High-performance procedural audio and music synthesizer.
 * Generates crisp 16-bit sound effects and atmospheric background music in real-time,
 * guaranteeing zero missing audio assets or network latency.
 */
class SoundManager(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var isSoundEnabled: Boolean = true
    var isMusicEnabled: Boolean = true
    var isHapticsEnabled: Boolean = true

    private val sampleRate = 22050
    private val audioScope = CoroutineScope(Dispatchers.Default)
    private var musicJob: Job? = null

    // Cache pre-synthesized PCM buffers for instant low-latency playback
    private val sfxBuffers = mutableMapOf<SoundType, ShortArray>()

    enum class SoundType {
        SLASH,
        HIT,
        SHURIKEN,
        JUMP,
        DOUBLE_JUMP,
        DASH,
        COIN,
        SCROLL,
        HURT,
        CHECKPOINT,
        SLAM,
        VICTORY,
        GAME_OVER
    }

    init {
        precomputeBuffers()
    }

    private fun precomputeBuffers() {
        sfxBuffers[SoundType.SLASH] = generateSlashSound()
        sfxBuffers[SoundType.HIT] = generateHitSound()
        sfxBuffers[SoundType.SHURIKEN] = generateShurikenSound()
        sfxBuffers[SoundType.JUMP] = generateJumpSound()
        sfxBuffers[SoundType.DOUBLE_JUMP] = generateDoubleJumpSound()
        sfxBuffers[SoundType.DASH] = generateDashSound()
        sfxBuffers[SoundType.COIN] = generateCoinSound()
        sfxBuffers[SoundType.SCROLL] = generateScrollSound()
        sfxBuffers[SoundType.HURT] = generateHurtSound()
        sfxBuffers[SoundType.CHECKPOINT] = generateCheckpointSound()
        sfxBuffers[SoundType.SLAM] = generateSlamSound()
        sfxBuffers[SoundType.VICTORY] = generateVictorySound()
        sfxBuffers[SoundType.GAME_OVER] = generateGameOverSound()
    }

    fun playSound(type: SoundType) {
        if (!isSoundEnabled) return
        val buffer = sfxBuffers[type] ?: return
        audioScope.launch {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                // Auto release after sound plays
                val durationMs = (buffer.size * 1000L) / sampleRate + 50L
                delay(durationMs)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }

    fun triggerHaptic(durationMs: Long = 35, amplitude: Int = 180) {
        if (!isHapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(
                        durationMs.coerceAtLeast(10),
                        amplitude.coerceIn(1, 255)
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {
        }
    }

    fun startMusic() {
        if (musicJob?.isActive == true) return
        musicJob = audioScope.launch {
            // Traditional Japanese Hirajoshi / Insen pentatonic scale frequencies (Hz):
            // D4 (293.66), Eb4 (311.13), G4 (392.00), A4 (440.00), Bb4 (466.16), D5 (587.33), Eb5 (622.25)
            val scale = doubleArrayOf(293.66, 311.13, 392.00, 440.00, 466.16, 587.33)
            val melodyNotes = intArrayOf(
                0, 2, 3, 4, 3, 2, 0, -1,
                2, 3, 5, 4, 3, 2, 1, 0,
                -1, 0, 2, 4, 5, 4, 2, 0,
                3, 2, 1, 0, 2, 0, -1, 0
            )

            var noteIdx = 0
            while (isActive) {
                if (!isMusicEnabled) {
                    delay(300)
                    continue
                }

                val note = melodyNotes[noteIdx % melodyNotes.size]
                noteIdx++

                if (note >= 0) {
                    val freq = scale[note % scale.size]
                    val durationMs = 320
                    playSynthNote(freq, durationMs, isPluck = true)
                } else {
                    // Percussive taiko accent
                    playDrumAccent()
                }

                delay(260)
            }
        }
    }

    fun stopMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    private fun playSynthNote(freq: Double, durationMs: Int, isPluck: Boolean) {
        audioScope.launch {
            try {
                val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    // Koto string synthesis with harmonics and exponential decay envelope
                    val envelope = kotlin.math.exp(-i.toDouble() / (sampleRate * 0.18))
                    val fund = sin(2.0 * PI * freq * t)
                    val harm1 = 0.5 * sin(2.0 * PI * freq * 2.0 * t)
                    val harm2 = 0.25 * sin(2.0 * PI * freq * 3.0 * t)
                    val sample = ((fund + harm1 + harm2) * envelope * 0.35 * Short.MAX_VALUE).toInt()
                    buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                delay(durationMs.toLong() + 20)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun playDrumAccent() {
        audioScope.launch {
            try {
                val numSamples = (sampleRate * 0.25).toInt()
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val envelope = kotlin.math.exp(-i.toDouble() / (sampleRate * 0.06))
                    val pitch = 85.0 * (1.0 - (i.toDouble() / numSamples) * 0.4)
                    val sample = (sin(2.0 * PI * pitch * (i.toDouble() / sampleRate)) * envelope * 0.4 * Short.MAX_VALUE).toInt()
                    buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                delay(260)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }

    // --- Sound Synthesis Algorithms ---

    private fun generateSlashSound(): ShortArray {
        val length = (sampleRate * 0.16).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 1200.0 - progress * 800.0
            val env = sin(progress * PI)
            val noise = (Math.random() * 2.0 - 1.0) * 0.5
            val tone = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * 0.5
            buffer[i] = ((tone + noise) * env * 0.7 * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateHitSound(): ShortArray {
        val length = (sampleRate * 0.20).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val env = kotlin.math.exp(-progress * 12.0)
            val noise = (Math.random() * 2.0 - 1.0) * 0.6
            val metallic = sin(2.0 * PI * 1850.0 * (i.toDouble() / sampleRate)) * 0.4
            buffer[i] = ((noise + metallic) * env * 0.85 * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateShurikenSound(): ShortArray {
        val length = (sampleRate * 0.14).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 600.0 + sin(progress * 16.0 * PI) * 350.0
            val env = sin(progress * PI)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.65
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateJumpSound(): ShortArray {
        val length = (sampleRate * 0.12).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 220.0 + progress * 400.0
            val env = (1.0 - progress) * (1.0 - progress)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.55
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateDoubleJumpSound(): ShortArray {
        val length = (sampleRate * 0.15).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 450.0 + progress * 550.0
            val env = sin(progress * PI)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.65
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateDashSound(): ShortArray {
        val length = (sampleRate * 0.22).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val env = sin(progress * PI)
            val noise = (Math.random() * 2.0 - 1.0)
            val tone = sin(2.0 * PI * 180.0 * (i.toDouble() / sampleRate))
            val sample = (noise * 0.6 + tone * 0.4) * env * 0.65
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateCoinSound(): ShortArray {
        val length = (sampleRate * 0.20).toInt()
        val buffer = ShortArray(length)
        val half = length / 2
        for (i in 0 until length) {
            val freq = if (i < half) 987.77 else 1318.51 // B5 then E6
            val env = if (i < half) (1.0 - i.toDouble() / half) else (1.0 - (i - half).toDouble() / half)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.6
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateScrollSound(): ShortArray {
        val length = (sampleRate * 0.45).toInt()
        val buffer = ShortArray(length)
        val part = length / 3
        for (i in 0 until length) {
            val note = i / part
            val freq = when (note) {
                0 -> 587.33 // D5
                1 -> 783.99 // G5
                else -> 1174.66 // D6
            }
            val env = kotlin.math.exp(-((i % part).toDouble() / (sampleRate * 0.08)))
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.7
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateHurtSound(): ShortArray {
        val length = (sampleRate * 0.22).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 180.0 - progress * 90.0
            val env = kotlin.math.exp(-progress * 8.0)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.75
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateCheckpointSound(): ShortArray {
        val length = (sampleRate * 0.35).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 659.25 + progress * 400.0 // E5 upward shimmer
            val env = kotlin.math.exp(-progress * 5.0)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.6
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateSlamSound(): ShortArray {
        val length = (sampleRate * 0.40).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 90.0 * (1.0 - progress * 0.7)
            val env = kotlin.math.exp(-progress * 6.0)
            val noise = (Math.random() * 2.0 - 1.0) * 0.4
            val sample = (sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) + noise) * env * 0.9
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateVictorySound(): ShortArray {
        val length = (sampleRate * 0.8).toInt()
        val buffer = ShortArray(length)
        val tones = doubleArrayOf(392.0, 440.0, 587.33, 659.25, 880.0) // G4, A4, D5, E5, A5
        val step = length / tones.size
        for (i in 0 until length) {
            val tIdx = (i / step).coerceIn(0, tones.size - 1)
            val freq = tones[tIdx]
            val localT = (i % step).toDouble() / sampleRate
            val env = kotlin.math.exp(-localT * 8.0)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.7
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }

    private fun generateGameOverSound(): ShortArray {
        val length = (sampleRate * 0.6).toInt()
        val buffer = ShortArray(length)
        for (i in 0 until length) {
            val progress = i.toDouble() / length
            val freq = 160.0 - progress * 80.0
            val env = kotlin.math.exp(-progress * 4.0)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.7
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return buffer
    }
}
