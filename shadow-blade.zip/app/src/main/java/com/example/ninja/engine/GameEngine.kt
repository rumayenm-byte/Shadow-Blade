package com.example.ninja.engine

import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ninja.model.*
import kotlin.math.*

class GameEngine(
    val levelData: LevelData,
    val preferences: GamePreferences,
    val soundManager: SoundManager
) {
    var player: Player = Player(
        x = levelData.spawnX,
        y = levelData.spawnY,
        health = preferences.getMaxHealth(),
        maxHealth = preferences.getMaxHealth(),
        shurikens = preferences.getMaxShurikens(),
        maxShurikens = preferences.getMaxShurikens()
    )

    private var activeCheckpointX = levelData.spawnX
    private var activeCheckpointY = levelData.spawnY

    val platforms = levelData.platforms.toMutableList()
    val traps = levelData.traps.toMutableList()
    val enemies = levelData.enemies.toMutableList()
    val collectibles = levelData.collectibles.toMutableList()
    val checkpoints = levelData.checkpoints.toMutableList()
    val projectiles = mutableListOf<Projectile>()
    val particles = mutableListOf<Particle>()

    // Inputs
    var inputLeft = false
    var inputRight = false
    var inputJumpPressed = false
    var inputAttackPressed = false
    var inputShurikenPressed = false
    var inputDashPressed = false

    // Game state
    var isGameOver = false
    var isVictory = false
    var cameraX = 0f
    var cameraY = 0f
    var screenShakeTime = 0f
    var screenShakeIntensity = 0f

    // Constants
    private val gravity = 1450f
    private val maxFallSpeed = 950f
    private val moveSpeed = 360f
    private val jumpVelocity = -640f
    private val doubleJumpVelocity = -580f
    private val wallSlideSpeed = 140f
    private val dashSpeed = 780f
    private val dashDuration = 0.22f

    // Atmosphere
    private var sakuraSpawnTimer = 0f

    init {
        // Pre-populate ambient cherry blossom petals
        for (i in 0..25) {
            val px = (Math.random() * levelData.width).toFloat()
            val py = (Math.random() * levelData.height).toFloat()
            particles.add(
                Particle(
                    x = px,
                    y = py,
                    vx = (Math.random() * 40 - 70).toFloat(),
                    vy = (Math.random() * 30 + 35).toFloat(),
                    size = (Math.random() * 4 + 4).toFloat(),
                    alpha = (Math.random() * 0.5 + 0.4).toFloat(),
                    color = 0xFFFF7088,
                    lifetime = (Math.random() * 8 + 4).toFloat(),
                    maxLifetime = 12f,
                    type = ParticleType.SAKURA_PETAL,
                    rotSpeed = (Math.random() * 2 - 1).toFloat()
                )
            )
        }
    }

    fun update(dt: Float) {
        val clampedDt = dt.coerceIn(0.001f, 0.05f)

        if (screenShakeTime > 0f) {
            screenShakeTime -= clampedDt
            if (screenShakeTime <= 0f) screenShakeIntensity = 0f
        }

        if (isGameOver || isVictory) {
            updateParticles(clampedDt)
            return
        }

        updatePlayer(clampedDt)
        updateTraps(clampedDt)
        updateEnemies(clampedDt)
        updateProjectiles(clampedDt)
        updateCollectibles(clampedDt)
        updateCheckpoints()
        updateParticles(clampedDt)
        checkLevelCompletion()
        updateCamera(clampedDt)
    }

    private fun updatePlayer(dt: Float) {
        player.animTimer += dt

        // Cooldowns & timers
        if (player.dashCooldownTimer > 0f) player.dashCooldownTimer -= dt
        if (player.invulnerableTimer > 0f) player.invulnerableTimer -= dt
        if (player.hurtTimer > 0f) player.hurtTimer -= dt

        // Shuriken natural recharge
        if (player.shurikens < player.maxShurikens) {
            player.shurikenRechargeTimer += dt
            if (player.shurikenRechargeTimer >= 4.0f) {
                player.shurikens++
                player.shurikenRechargeTimer = 0f
            }
        }

        // Ghost trails for dashing
        val iterator = player.ghostTrails.iterator()
        while (iterator.hasNext()) {
            val ghost = iterator.next()
            ghost.alpha -= dt * 3.5f
            if (ghost.alpha <= 0f) iterator.remove()
        }

        // Handle Dash
        if (inputDashPressed && player.dashCooldownTimer <= 0f && player.dashTimer <= 0f) {
            inputDashPressed = false
            player.dashTimer = dashDuration
            player.dashCooldownTimer = preferences.getDashCooldown()
            val dashDir = if (player.facingRight) 1f else -1f
            player.vx = dashDir * dashSpeed
            player.vy = 0f
            soundManager.playSound(SoundManager.SoundType.DASH)
            soundManager.triggerHaptic(25, 120)
            spawnDashDust()
        }

        if (player.dashTimer > 0f) {
            player.dashTimer -= dt
            player.state = PlayerState.DASHING
            if (Math.random() < 0.6) {
                player.ghostTrails.add(
                    GhostTrail(player.x, player.y, player.facingRight, alpha = 0.6f)
                )
            }
            player.x += player.vx * dt
            // Check wall collisions while dashing
            resolveHorizontalPlatformCollisions()
            return
        }

        // Handle Katana Slash
        if (inputAttackPressed && player.slashTimer <= 0f) {
            inputAttackPressed = false
            player.slashTimer = 0.35f
            player.slashCombo = if (player.slashCombo >= 3) 1 else player.slashCombo + 1
            soundManager.playSound(SoundManager.SoundType.SLASH)
            soundManager.triggerHaptic(25, 170)
            spawnSlashArcParticle()
            checkSlashEnemyHits()
        }

        if (player.slashTimer > 0f) {
            player.slashTimer -= dt
            player.state = PlayerState.SLASHING
        }

        // Handle Shuriken Throw
        if (inputShurikenPressed && player.shurikens > 0) {
            inputShurikenPressed = false
            player.shurikens--
            soundManager.playSound(SoundManager.SoundType.SHURIKEN)
            soundManager.triggerHaptic(15, 100)
            val projSpeed = 750f
            val pDir = if (player.facingRight) 1f else -1f
            projectiles.add(
                Projectile(
                    x = player.x + pDir * 20f,
                    y = player.y - 32f,
                    vx = pDir * projSpeed,
                    vy = -20f,
                    radius = 10f,
                    isPlayer = true,
                    damage = preferences.getKatanaDamage() * 0.75f,
                    type = ProjectileType.SHURIKEN
                )
            )
        }

        // Horizontal Movement
        var targetVx = 0f
        if (inputLeft) {
            targetVx -= moveSpeed
            player.facingRight = false
        }
        if (inputRight) {
            targetVx += moveSpeed
            player.facingRight = true
        }

        player.vx = targetVx

        // Wall Slide Check
        player.isWallSliding = false
        if (!player.isGrounded && player.vy > 0f) {
            val checkDist = 12f
            val leftCheck = Hitbox(player.x - player.width / 2f - checkDist, player.y - player.height + 10f, player.x - player.width / 2f, player.y - 10f)
            val rightCheck = Hitbox(player.x + player.width / 2f, player.y - player.height + 10f, player.x + player.width / 2f + checkDist, player.y - 10f)

            for (plat in platforms) {
                if (plat.hitbox.intersects(leftCheck) && inputLeft) {
                    player.isWallSliding = true
                    player.wallSlideDir = -1
                    break
                } else if (plat.hitbox.intersects(rightCheck) && inputRight) {
                    player.isWallSliding = true
                    player.wallSlideDir = 1
                    break
                }
            }
        }

        // Handle Jump
        if (inputJumpPressed) {
            inputJumpPressed = false
            if (player.isGrounded) {
                // First Jump
                player.vy = jumpVelocity
                player.isGrounded = false
                player.canDoubleJump = true
                soundManager.playSound(SoundManager.SoundType.JUMP)
                soundManager.triggerHaptic(15, 110)
                spawnJumpDust()
            } else if (player.isWallSliding) {
                // Wall Jump kick off
                player.vy = jumpVelocity * 0.95f
                player.vx = -player.wallSlideDir * moveSpeed * 1.25f
                player.facingRight = player.wallSlideDir < 0
                player.isWallSliding = false
                player.canDoubleJump = true
                soundManager.playSound(SoundManager.SoundType.DOUBLE_JUMP)
                soundManager.triggerHaptic(20, 140)
                spawnJumpDust()
            } else if (player.canDoubleJump) {
                // Double Jump flip
                player.vy = doubleJumpVelocity
                player.canDoubleJump = false
                soundManager.playSound(SoundManager.SoundType.DOUBLE_JUMP)
                soundManager.triggerHaptic(20, 130)
                spawnDoubleJumpRing()
            }
        }

        // Apply Gravity
        if (player.isWallSliding) {
            player.vy = wallSlideSpeed
            player.state = PlayerState.WALL_SLIDING
        } else {
            player.vy = (player.vy + gravity * dt).coerceAtMost(maxFallSpeed)
        }

        // Apply X movement
        player.x += player.vx * dt
        resolveHorizontalPlatformCollisions()

        // Apply Y movement
        val prevY = player.y
        player.y += player.vy * dt
        player.isGrounded = false
        resolveVerticalPlatformCollisions(prevY)

        // Set Animation State
        if (player.slashTimer <= 0f) {
            player.state = when {
                player.isWallSliding -> PlayerState.WALL_SLIDING
                !player.isGrounded && player.vy < -50f -> PlayerState.JUMPING
                !player.isGrounded && player.vy >= -50f -> PlayerState.FALLING
                abs(player.vx) > 20f -> PlayerState.RUNNING
                else -> PlayerState.IDLE
            }
        }

        // Check if fell out of level
        if (player.y > levelData.height + 150f) {
            damagePlayer(1, respawnAtCheckpoint = true)
        }
    }

    private fun resolveHorizontalPlatformCollisions() {
        val hb = player.hitbox
        for (plat in platforms) {
            val pHB = plat.hitbox
            if (pHB.intersects(hb)) {
                // A platform is only a horizontal wall if the player penetrates the side of the wall,
                // NOT when the player is walking or standing on top of it!
                val footPenetration = hb.bottom - pHB.top
                val headPenetration = pHB.bottom - hb.top
                if (footPenetration > 14f && headPenetration > 10f) {
                    if (player.vx > 0f && hb.right > pHB.left && hb.left < pHB.left) {
                        player.x = pHB.left - player.width / 2f
                        player.vx = 0f
                    } else if (player.vx < 0f && hb.left < pHB.right && hb.right > pHB.right) {
                        player.x = pHB.right + player.width / 2f
                        player.vx = 0f
                    }
                }
            }
        }
    }

    private fun resolveVerticalPlatformCollisions(prevY: Float) {
        val hb = player.hitbox
        for (plat in platforms) {
            val pHB = plat.hitbox
            val overlapsX = hb.right > pHB.left + 2f && hb.left < pHB.right - 2f
            if (!overlapsX) continue

            // 1. Landing on platform top (moving downwards or standing)
            if (player.vy >= 0f) {
                val maxSnap = (player.vy * 0.05f).coerceAtLeast(24f)
                if (prevY <= pHB.top + 8f && player.y >= pHB.top - 4f && player.y <= pHB.top + maxSnap) {
                    player.y = pHB.top
                    player.vy = 0f
                    player.isGrounded = true
                    player.canDoubleJump = true
                }
            }
            // 2. Hitting ceiling (moving upwards)
            else if (player.vy < 0f) {
                val prevTop = prevY - player.height
                val currentTop = hb.top
                if (prevTop >= pHB.bottom - 8f && currentTop <= pHB.bottom) {
                    player.y = pHB.bottom + player.height
                    player.vy = 0f
                }
            }
        }
    }

    private fun updateTraps(dt: Float) {
        val playerHb = player.hitbox

        for (trap in traps) {
            when (trap.type) {
                TrapType.SPINNING_SAW -> {
                    trap.x += trap.speed * trap.direction * dt
                    if (trap.x >= trap.maxX) {
                        trap.x = trap.maxX
                        trap.direction = -1f
                    } else if (trap.x <= trap.minX) {
                        trap.x = trap.minX
                        trap.direction = 1f
                    }
                }
                TrapType.SWINGING_MACE -> {
                    trap.fireTimer += dt * trap.swingSpeed
                    trap.angle = sin(trap.fireTimer) * (PI.toFloat() * 0.35f)
                }
                TrapType.DART_SHOOTER -> {
                    trap.fireTimer += dt
                    if (trap.fireTimer >= trap.fireCooldown) {
                        trap.fireTimer = 0f
                        // Shoot dart
                        projectiles.add(
                            Projectile(
                                x = trap.x + trap.direction * 15f,
                                y = trap.y + trap.height / 2f,
                                vx = trap.direction * 350f,
                                vy = 0f,
                                radius = 6f,
                                isPlayer = false,
                                damage = 1f,
                                type = ProjectileType.DART
                            )
                        )
                    }
                }
                TrapType.SPIKE_PIT -> {}
                TrapType.CRUMBLING_PLATFORM -> {}
            }

            // Trap damage collision
            if (!player.isInvulnerable() && trap.hitbox.intersects(playerHb)) {
                damagePlayer(1, respawnAtCheckpoint = (trap.type == TrapType.SPIKE_PIT && player.y > levelData.height - 100f))
                triggerScreenShake(0.2f, 10f)
            }
        }
    }

    private fun updateEnemies(dt: Float) {
        val playerHb = player.hitbox

        for (enemy in enemies) {
            if (enemy.state == EnemyState.DEAD) continue

            enemy.animTimer += dt
            if (enemy.hurtTimer > 0f) enemy.hurtTimer -= dt

            val distToPlayer = hypot(player.x - enemy.x, (player.y - enemy.y))

            when (enemy.type) {
                EnemyType.ASHIGARU -> {
                    // Patrol or charge
                    if (distToPlayer < 240f && abs(player.y - enemy.y) < 80f) {
                        enemy.state = EnemyState.ALERT
                        enemy.facingRight = player.x > enemy.x
                        val dir = if (enemy.facingRight) 1f else -1f
                        enemy.vx = dir * 160f
                    } else {
                        enemy.state = EnemyState.PATROL
                        if (enemy.facingRight) {
                            enemy.vx = 80f
                            if (enemy.x >= enemy.patrolMaxX) enemy.facingRight = false
                        } else {
                            enemy.vx = -80f
                            if (enemy.x <= enemy.patrolMinX) enemy.facingRight = true
                        }
                    }
                    enemy.x += enemy.vx * dt

                    // Attack if in range
                    if (distToPlayer < 55f && enemy.attackTimer <= 0f) {
                        enemy.attackTimer = enemy.attackCooldown
                        if (!player.isInvulnerable()) {
                            damagePlayer(1)
                        }
                    }
                }

                EnemyType.ARCHER -> {
                    enemy.facingRight = player.x > enemy.x
                    enemy.attackTimer -= dt
                    if (enemy.attackTimer <= 0f && distToPlayer < 650f) {
                        enemy.attackTimer = 2.4f
                        val dir = if (enemy.facingRight) 1f else -1f
                        projectiles.add(
                            Projectile(
                                x = enemy.x + dir * 25f,
                                y = enemy.y - 35f,
                                vx = dir * 420f,
                                vy = -40f,
                                radius = 7f,
                                isPlayer = false,
                                damage = 1f,
                                type = ProjectileType.ARROW
                            )
                        )
                    }
                }

                EnemyType.ASSASSIN -> {
                    // Fast acrobat, dashes toward player
                    enemy.facingRight = player.x > enemy.x
                    val dir = if (enemy.facingRight) 1f else -1f
                    if (distToPlayer < 350f) {
                        enemy.vx = dir * 220f
                    } else {
                        enemy.vx = dir * 110f
                    }
                    enemy.x += enemy.vx * dt
                    if (distToPlayer < 60f && enemy.attackTimer <= 0f) {
                        enemy.attackTimer = 1.3f
                        if (!player.isInvulnerable()) {
                            damagePlayer(1)
                        }
                    }
                }

                EnemyType.SHIELD_BRUTE -> {
                    // Heavy guard, blocks frontal damage
                    enemy.facingRight = player.x > enemy.x
                    val dir = if (enemy.facingRight) 1f else -1f
                    enemy.vx = dir * 65f
                    enemy.x += enemy.vx * dt
                    if (distToPlayer < 65f && enemy.attackTimer <= 0f) {
                        enemy.attackTimer = 2.0f
                        if (!player.isInvulnerable()) {
                            damagePlayer(1)
                        }
                    }
                }

                EnemyType.BOSS_KURO -> {
                    updateBossKuro(enemy, dt, distToPlayer)
                }
            }

            if (enemy.attackTimer > 0f) enemy.attackTimer -= dt

            // Check body collision with player
            if (!player.isInvulnerable() && enemy.hitbox.intersects(playerHb)) {
                damagePlayer(1)
            }
        }
    }

    private fun updateBossKuro(boss: Enemy, dt: Float, distToPlayer: Float) {
        boss.facingRight = player.x > boss.x
        boss.bossSpecialCooldown -= dt

        // Phase 2 transition at < 50% health
        if (boss.health < boss.maxHealth * 0.5f && boss.bossPhase == 1) {
            boss.bossPhase = 2
            triggerScreenShake(0.5f, 18f)
            soundManager.playSound(SoundManager.SoundType.SLAM)
            spawnBossRageParticles(boss)
        }

        val speed = if (boss.bossPhase == 2) 180f else 110f
        val dir = if (boss.facingRight) 1f else -1f

        if (distToPlayer > 120f) {
            boss.vx = dir * speed
            boss.x += boss.vx * dt
        }

        // Boss Attack 1: Shockwave Slam
        if (boss.bossSpecialCooldown <= 0f) {
            boss.bossSpecialCooldown = if (boss.bossPhase == 2) 2.5f else 4.0f
            soundManager.playSound(SoundManager.SoundType.SLAM)
            soundManager.triggerHaptic(40, 220)
            triggerScreenShake(0.4f, 15f)

            // Spawn shockwaves traveling left and right along ground
            projectiles.add(
                Projectile(
                    x = boss.x - 30f,
                    y = boss.y - 15f,
                    vx = -450f,
                    vy = 0f,
                    radius = 24f,
                    isPlayer = false,
                    damage = 1f,
                    type = ProjectileType.BOSS_SHOCKWAVE
                )
            )
            projectiles.add(
                Projectile(
                    x = boss.x + 30f,
                    y = boss.y - 15f,
                    vx = 450f,
                    vy = 0f,
                    radius = 24f,
                    isPlayer = false,
                    damage = 1f,
                    type = ProjectileType.BOSS_SHOCKWAVE
                )
            )
        }

        // Boss Melee Katana Strike
        if (distToPlayer < 95f && boss.attackTimer <= 0f) {
            boss.attackTimer = 1.4f
            soundManager.playSound(SoundManager.SoundType.SLASH)
            if (!player.isInvulnerable()) {
                damagePlayer(1)
                triggerScreenShake(0.3f, 12f)
            }
        }
    }

    private fun updateProjectiles(dt: Float) {
        val playerHb = player.hitbox
        val projIterator = projectiles.iterator()

        while (projIterator.hasNext()) {
            val p = projIterator.next()
            p.lifetime -= dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rotation += 15f

            if (p.lifetime <= 0f) {
                projIterator.remove()
                continue
            }

            // Platform collision (walls block arrows/shurikens)
            var hitPlatform = false
            for (plat in platforms) {
                if (plat.hitbox.contains(p.x, p.y)) {
                    hitPlatform = true
                    break
                }
            }
            if (hitPlatform) {
                spawnSparks(p.x, p.y, count = 5)
                projIterator.remove()
                continue
            }

            // Player hit by enemy projectile
            if (!p.isPlayer && !player.isInvulnerable() && p.hitbox.intersects(playerHb)) {
                damagePlayer(p.damage.toInt())
                projIterator.remove()
                continue
            }

            // Enemy hit by player shuriken
            if (p.isPlayer) {
                var hitEnemy = false
                for (enemy in enemies) {
                    if (enemy.state != EnemyState.DEAD && enemy.hitbox.intersects(p.hitbox)) {
                        hitEnemy = true
                        damageEnemy(enemy, p.damage, isBackstab = (enemy.facingRight == (p.vx > 0)))
                        spawnSparks(p.x, p.y, count = 8)
                        soundManager.playSound(SoundManager.SoundType.HIT)
                        break
                    }
                }
                if (hitEnemy) {
                    projIterator.remove()
                }
            }
        }
    }

    private fun checkSlashEnemyHits() {
        val attackHb = player.attackHitbox
        val damage = preferences.getKatanaDamage()

        for (enemy in enemies) {
            if (enemy.state != EnemyState.DEAD && enemy.hitbox.intersects(attackHb)) {
                // Shield brute blocks front attacks
                val isBackstab = (player.x > enemy.x && enemy.facingRight) || (player.x < enemy.x && !enemy.facingRight)
                if (enemy.type == EnemyType.SHIELD_BRUTE && !isBackstab) {
                    // Blocked!
                    soundManager.playSound(SoundManager.SoundType.HIT)
                    spawnSparks(enemy.x, enemy.y - 30f, count = 12)
                    enemy.vx = if (player.facingRight) 60f else -60f
                } else {
                    damageEnemy(enemy, damage, isBackstab)
                }
            }
        }
    }

    private fun damageEnemy(enemy: Enemy, amount: Float, isBackstab: Boolean) {
        val multiplier = if (isBackstab) 1.5f else 1.0f
        val finalDamage = amount * multiplier

        enemy.health -= finalDamage
        enemy.hurtTimer = 0.2f
        soundManager.playSound(SoundManager.SoundType.HIT)
        soundManager.triggerHaptic(25, 170)

        // Spawn blood/spark particles
        spawnBloodSpurt(enemy.x, enemy.y - enemy.height / 2f)
        spawnSparks(enemy.x, enemy.y - enemy.height / 2f, count = 10)

        if (enemy.health <= 0f) {
            enemy.state = EnemyState.DEAD
            spawnSparks(enemy.x, enemy.y - enemy.height / 2f, count = 20)
            // Drop coins
            val coinCount = if (enemy.isBoss) 8 else 2
            for (i in 0 until coinCount) {
                collectibles.add(
                    Collectible(
                        id = (Math.random() * 10000).toInt(),
                        type = CollectibleType.COIN,
                        x = enemy.x + (Math.random() * 40 - 20).toFloat(),
                        y = enemy.y - (Math.random() * 30 + 10).toFloat()
                    )
                )
            }
            if (enemy.isBoss) {
                soundManager.playSound(SoundManager.SoundType.VICTORY)
                isVictory = true
                preferences.setLevelStars(levelData.id, 3)
                preferences.unlockedLevel = max(preferences.unlockedLevel, levelData.id + 1)
            }
        }
    }

    fun damagePlayer(amount: Int, respawnAtCheckpoint: Boolean = false) {
        if (player.isInvulnerable() || isGameOver) return

        player.health = (player.health - amount).coerceAtLeast(0)
        player.invulnerableTimer = 1.2f
        player.hurtTimer = 0.35f
        soundManager.playSound(SoundManager.SoundType.HURT)
        soundManager.triggerHaptic(50, 240)
        triggerScreenShake(0.35f, 14f)

        spawnBloodSpurt(player.x, player.y - 30f)

        if (respawnAtCheckpoint && player.health > 0) {
            player.x = activeCheckpointX
            player.y = activeCheckpointY - 10f
            player.vx = 0f
            player.vy = 0f
        }

        if (player.health <= 0) {
            player.state = PlayerState.DEAD
            isGameOver = true
            soundManager.playSound(SoundManager.SoundType.GAME_OVER)
        }
    }

    private fun updateCollectibles(dt: Float) {
        val playerHb = player.hitbox
        val iterator = collectibles.iterator()

        while (iterator.hasNext()) {
            val item = iterator.next()
            if (item.collected) {
                iterator.remove()
                continue
            }

            // Coin magnet attraction
            val dist = hypot(player.x - item.x, (player.y - 25f - item.y))
            if (dist < 110f) {
                val pullSpeed = 400f * dt
                item.x += (player.x - item.x) / dist * pullSpeed
                item.y += (player.y - 25f - item.y) / dist * pullSpeed
            }

            if (item.hitbox.intersects(playerHb)) {
                item.collected = true
                when (item.type) {
                    CollectibleType.COIN -> {
                        player.coinsCollected++
                        preferences.coins += 1
                        soundManager.playSound(SoundManager.SoundType.COIN)
                        soundManager.triggerHaptic(10, 80)
                        spawnSparks(item.x, item.y, count = 6, color = 0xFFFFD700)
                    }
                    CollectibleType.SCROLL -> {
                        player.scrollsCollected++
                        preferences.setScrollFound(levelData.id, player.scrollsCollected)
                        soundManager.playSound(SoundManager.SoundType.SCROLL)
                        soundManager.triggerHaptic(35, 180)
                        spawnSparks(item.x, item.y, count = 18, color = 0xFF00E5FF)
                    }
                    CollectibleType.HEART -> {
                        if (player.health < player.maxHealth) {
                            player.health++
                        }
                        soundManager.playSound(SoundManager.SoundType.CHECKPOINT)
                        spawnSparks(item.x, item.y, count = 10, color = 0xFFFF3344)
                    }
                }
                iterator.remove()
            }
        }
    }

    private fun updateCheckpoints() {
        val playerHb = player.hitbox
        for (cp in checkpoints) {
            if (!cp.activated && cp.hitbox.intersects(playerHb)) {
                cp.activated = true
                activeCheckpointX = cp.x
                activeCheckpointY = cp.y
                soundManager.playSound(SoundManager.SoundType.CHECKPOINT)
                soundManager.triggerHaptic(30, 160)
                spawnSparks(cp.x, cp.y - 30f, count = 25, color = 0xFF00E5FF)
            }
        }
    }

    private fun checkLevelCompletion() {
        if (!isVictory && levelData.portal.hitbox.intersects(player.hitbox)) {
            isVictory = true
            soundManager.playSound(SoundManager.SoundType.VICTORY)
            val stars = 1 + (if (player.scrollsCollected >= 2) 1 else 0) + (if (player.scrollsCollected >= 3) 1 else 0)
            preferences.setLevelStars(levelData.id, stars)
            preferences.unlockedLevel = max(preferences.unlockedLevel, levelData.id + 1)
        }
    }

    private fun updateCamera(dt: Float) {
        val targetCamX = player.x - 420f + (if (player.facingRight) 80f else -80f)
        val targetCamY = (player.y - 320f).coerceIn(0f, levelData.height - 540f)

        cameraX += (targetCamX - cameraX) * 0.12f
        cameraY += (targetCamY - cameraY) * 0.10f

        cameraX = cameraX.coerceIn(0f, max(0f, levelData.width - 860f))
    }

    private fun triggerScreenShake(time: Float, intensity: Float) {
        screenShakeTime = time
        screenShakeIntensity = intensity
    }

    // --- Particle Spawners ---

    private fun updateParticles(dt: Float) {
        sakuraSpawnTimer += dt
        if (sakuraSpawnTimer >= 0.35f) {
            sakuraSpawnTimer = 0f
            // Spawn gentle sakura petals in camera view
            particles.add(
                Particle(
                    x = cameraX + 900f,
                    y = cameraY + (Math.random() * 500).toFloat(),
                    vx = -(Math.random() * 60 + 50).toFloat(),
                    vy = (Math.random() * 40 + 20).toFloat(),
                    size = (Math.random() * 4 + 4).toFloat(),
                    alpha = 0.8f,
                    color = 0xFFFF80AB,
                    lifetime = 10f,
                    maxLifetime = 10f,
                    type = ParticleType.SAKURA_PETAL
                )
            )
        }

        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.lifetime -= dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.alpha = (p.lifetime / p.maxLifetime).coerceIn(0f, 1f)

            if (p.lifetime <= 0f) it.remove()
        }
    }

    private fun spawnSlashArcParticle() {
        val dir = if (player.facingRight) 1f else -1f
        particles.add(
            Particle(
                x = player.x + dir * 32f,
                y = player.y - 28f,
                vx = dir * 60f,
                vy = 0f,
                size = 58f,
                alpha = 1f,
                color = 0xFFFFFFFF,
                lifetime = 0.26f,
                maxLifetime = 0.26f,
                type = ParticleType.SLASH_TRAIL
            )
        )
        // Spawn energetic blade swing sparks
        for (i in 0..4) {
            particles.add(
                Particle(
                    x = player.x + dir * 36f,
                    y = player.y - 28f + (Math.random() * 20 - 10).toFloat(),
                    vx = dir * (Math.random() * 120 + 80).toFloat(),
                    vy = (Math.random() * 80 - 40).toFloat(),
                    size = 3.5f,
                    alpha = 1f,
                    color = 0xFF00E5FF,
                    lifetime = 0.25f,
                    maxLifetime = 0.25f,
                    type = ParticleType.SPARK
                )
            )
        }
    }

    private fun spawnBloodSpurt(x: Float, y: Float) {
        for (i in 0..12) {
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (Math.random() * 260 - 130).toFloat(),
                    vy = (Math.random() * -200 - 40).toFloat(),
                    size = (Math.random() * 4 + 3).toFloat(),
                    alpha = 1f,
                    color = 0xFFD50000,
                    lifetime = 0.5f,
                    maxLifetime = 0.5f,
                    type = ParticleType.BLOOD_SPURT
                )
            )
        }
    }

    private fun spawnSparks(x: Float, y: Float, count: Int, color: Long = 0xFFFFEE58) {
        for (i in 0 until count) {
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (Math.random() * 320 - 160).toFloat(),
                    vy = (Math.random() * 320 - 160).toFloat(),
                    size = (Math.random() * 3 + 2).toFloat(),
                    alpha = 1f,
                    color = color,
                    lifetime = 0.35f,
                    maxLifetime = 0.35f,
                    type = ParticleType.SPARK
                )
            )
        }
    }

    private fun spawnJumpDust() {
        for (i in 0..5) {
            particles.add(
                Particle(
                    x = player.x + (Math.random() * 20 - 10).toFloat(),
                    y = player.y,
                    vx = (Math.random() * 80 - 40).toFloat(),
                    vy = -(Math.random() * 40 + 10).toFloat(),
                    size = 5f,
                    alpha = 0.6f,
                    color = 0xFF90A4AE,
                    lifetime = 0.3f,
                    maxLifetime = 0.3f,
                    type = ParticleType.DUST
                )
            )
        }
    }

    private fun spawnDoubleJumpRing() {
        particles.add(
            Particle(
                x = player.x,
                y = player.y - 20f,
                vx = 0f,
                vy = 0f,
                size = 35f,
                alpha = 0.9f,
                color = 0xFF00E5FF,
                lifetime = 0.25f,
                maxLifetime = 0.25f,
                type = ParticleType.SHOCKWAVE_RING
            )
        )
    }

    private fun spawnDashDust() {
        val dir = if (player.facingRight) -1f else 1f
        for (i in 0..8) {
            particles.add(
                Particle(
                    x = player.x + dir * 15f,
                    y = player.y - 15f,
                    vx = dir * (Math.random() * 120 + 40).toFloat(),
                    vy = -(Math.random() * 50).toFloat(),
                    size = 6f,
                    alpha = 0.8f,
                    color = 0xFF37474F,
                    lifetime = 0.35f,
                    maxLifetime = 0.35f,
                    type = ParticleType.DUST
                )
            )
        }
    }

    private fun spawnBossRageParticles(boss: Enemy) {
        for (i in 0..30) {
            particles.add(
                Particle(
                    x = boss.x + (Math.random() * 80 - 40).toFloat(),
                    y = boss.y - (Math.random() * 80).toFloat(),
                    vx = (Math.random() * 200 - 100).toFloat(),
                    vy = -(Math.random() * 250 + 50).toFloat(),
                    size = (Math.random() * 7 + 4).toFloat(),
                    alpha = 1f,
                    color = 0xFFFF1744,
                    lifetime = 0.7f,
                    maxLifetime = 0.7f,
                    type = ParticleType.SPARK
                )
            )
        }
    }
}
