package com.example.ninja.model

import kotlin.math.max
import kotlin.math.min

data class Hitbox(
    var left: Float,
    var top: Float,
    var right: Float,
    var bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    fun intersects(other: Hitbox): Boolean {
        return left < other.right && right > other.left && top < other.bottom && bottom > other.top
    }

    fun contains(x: Float, y: Float): Boolean {
        return x in left..right && y in top..bottom
    }

    fun set(l: Float, t: Float, r: Float, b: Float) {
        left = l
        top = t
        right = r
        bottom = b
    }
}

enum class PlayerState {
    IDLE,
    RUNNING,
    JUMPING,
    FALLING,
    WALL_SLIDING,
    SLASHING,
    DASHING,
    HURT,
    DEAD
}

data class GhostTrail(
    val x: Float,
    val y: Float,
    val facingRight: Boolean,
    var alpha: Float = 0.7f
)

data class Player(
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    val width: Float = 34f,
    val height: Float = 54f,
    var facingRight: Boolean = true,
    var state: PlayerState = PlayerState.IDLE,
    var health: Int = 3,
    var maxHealth: Int = 3,
    var shurikens: Int = 5,
    var maxShurikens: Int = 5,
    var shurikenRechargeTimer: Float = 0f,
    var canDoubleJump: Boolean = true,
    var isGrounded: Boolean = false,
    var isWallSliding: Boolean = false,
    var wallSlideDir: Int = 0, // -1 left wall, 1 right wall
    var slashTimer: Float = 0f,
    var slashCombo: Int = 1,
    var dashTimer: Float = 0f,
    var dashCooldownTimer: Float = 0f,
    var hurtTimer: Float = 0f,
    var invulnerableTimer: Float = 0f,
    var animTimer: Float = 0f,
    var coinsCollected: Int = 0,
    var scrollsCollected: Int = 0,
    val ghostTrails: MutableList<GhostTrail> = mutableListOf()
) {
    val hitbox: Hitbox
        get() = Hitbox(x - width / 2f, y - height, x + width / 2f, y)

    val attackHitbox: Hitbox
        get() {
            val reach = 55f
            val topOffset = -45f
            val bottomOffset = 5f
            return if (facingRight) {
                Hitbox(x, y + topOffset, x + reach, y + bottomOffset)
            } else {
                Hitbox(x - reach, y + topOffset, x, y + bottomOffset)
            }
        }

    fun isInvulnerable(): Boolean = invulnerableTimer > 0f || dashTimer > 0f
}

enum class EnemyType {
    ASHIGARU,     // Basic spear/sword guard
    ARCHER,       // Ranged bowman
    ASSASSIN,     // Agile jumping dual-wielder
    SHIELD_BRUTE, // Armored shield vanguard
    BOSS_KURO     // Lord Kuro (Warlord Boss)
}

enum class EnemyState {
    PATROL,
    ALERT,
    ATTACKING,
    HURT,
    DEAD
}

data class Enemy(
    val id: Int,
    val type: EnemyType,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var width: Float = 36f,
    var height: Float = 56f,
    var patrolMinX: Float = 0f,
    var patrolMaxX: Float = 0f,
    var facingRight: Boolean = true,
    var health: Float = 40f,
    var maxHealth: Float = 40f,
    var state: EnemyState = EnemyState.PATROL,
    var attackTimer: Float = 0f,
    var attackCooldown: Float = 1.6f,
    var hurtTimer: Float = 0f,
    var animTimer: Float = 0f,
    var bossPhase: Int = 1,
    var bossSpecialCooldown: Float = 3f,
    var isBoss: Boolean = false
) {
    val hitbox: Hitbox
        get() = Hitbox(x - width / 2f, y - height, x + width / 2f, y)

    val attackHitbox: Hitbox
        get() {
            val reach = if (isBoss) 85f else 45f
            val topOffset = if (isBoss) -75f else -45f
            return if (facingRight) {
                Hitbox(x, y + topOffset, x + reach, y)
            } else {
                Hitbox(x - reach, y + topOffset, x, y)
            }
        }
}

enum class TrapType {
    SPIKE_PIT,
    SPINNING_SAW,
    SWINGING_MACE,
    DART_SHOOTER,
    CRUMBLING_PLATFORM
}

data class Trap(
    val id: Int,
    val type: TrapType,
    var x: Float,
    var y: Float,
    var width: Float = 40f,
    var height: Float = 20f,
    // Dynamic trap params
    var minX: Float = 0f,
    var maxX: Float = 0f,
    var speed: Float = 80f,
    var direction: Float = 1f,
    var pivotX: Float = 0f,
    var pivotY: Float = 0f,
    var chainLength: Float = 120f,
    var angle: Float = 0f,
    var swingSpeed: Float = 2.2f,
    var fireCooldown: Float = 2.0f,
    var fireTimer: Float = 0f,
    var crumbleTimer: Float = -1f, // -1 not triggered, > 0 crumbling, -2 fallen
    var respawnTimer: Float = 0f
) {
    val hitbox: Hitbox
        get() = when (type) {
            TrapType.SWINGING_MACE -> {
                // Circular mace head at end of pendulum
                val maceX = pivotX + kotlin.math.sin(angle) * chainLength
                val maceY = pivotY + kotlin.math.cos(angle) * chainLength
                val rad = width / 2f
                Hitbox(maceX - rad, maceY - rad, maceX + rad, maceY + rad)
            }
            TrapType.SPINNING_SAW -> {
                val rad = width / 2f
                Hitbox(x - rad, y - rad, x + rad, y + rad)
            }
            else -> {
                Hitbox(x, y, x + width, y + height)
            }
        }
}

enum class ProjectileType {
    SHURIKEN,
    ARROW,
    DART,
    BOSS_SHOCKWAVE
}

data class Projectile(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float = 8f,
    val isPlayer: Boolean = true,
    val damage: Float = 20f,
    var rotation: Float = 0f,
    var lifetime: Float = 4.0f,
    val type: ProjectileType = ProjectileType.SHURIKEN
) {
    val hitbox: Hitbox
        get() = Hitbox(x - radius, y - radius, x + radius, y + radius)
}

enum class CollectibleType {
    COIN,
    SCROLL,
    HEART
}

data class Collectible(
    val id: Int,
    val type: CollectibleType,
    var x: Float,
    var y: Float,
    var width: Float = 24f,
    var height: Float = 24f,
    var collected: Boolean = false,
    var bounceOffset: Float = 0f
) {
    val hitbox: Hitbox
        get() = Hitbox(x - width / 2f, y - height / 2f, x + width / 2f, y + height / 2f)
}

data class Checkpoint(
    val x: Float,
    val y: Float,
    var activated: Boolean = false,
    var flameAnim: Float = 0f
) {
    val hitbox: Hitbox
        get() = Hitbox(x - 20f, y - 60f, x + 20f, y)
}

data class Portal(
    val x: Float,
    val y: Float,
    val width: Float = 50f,
    val height: Float = 80f
) {
    val hitbox: Hitbox
        get() = Hitbox(x, y - height, x + width, y)
}

data class Platform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val isBamboo: Boolean = false
) {
    val hitbox: Hitbox
        get() = Hitbox(x, y, x + width, y + height)
}

enum class ParticleType {
    SAKURA_PETAL,
    BLOOD_SPURT,
    SPARK,
    DUST,
    SLASH_TRAIL,
    SHOCKWAVE_RING
}

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var alpha: Float = 1f,
    val color: Long,
    var lifetime: Float,
    val maxLifetime: Float,
    val type: ParticleType,
    var rotation: Float = 0f,
    var rotSpeed: Float = 0f
)

enum class BackgroundTheme {
    BAMBOO_MOON,
    CRIMSON_SUNSET,
    SHADOW_FORTRESS,
    ECLIPSE_BLOOD_MOON
}

data class LevelData(
    val id: Int,
    val title: String,
    val subtitle: String,
    val width: Float,
    val height: Float,
    val spawnX: Float,
    val spawnY: Float,
    val portal: Portal,
    val platforms: List<Platform>,
    val traps: List<Trap>,
    val enemies: List<Enemy>,
    val collectibles: List<Collectible>,
    val checkpoints: List<Checkpoint>,
    val theme: BackgroundTheme
)
