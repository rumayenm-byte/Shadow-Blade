package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ninja Arashi Crimson & Shadow Palette
val Obsidian = Color(0xFF090C12)
val DarkSurface = Color(0xFF131824)
val DarkCard = Color(0xFF1C2233)
val ShadowRed = Color(0xFFD32F2F)
val Crimson = Color(0xFFFF3344)
val BloodMoon = Color(0xFFFF5252)
val StealthCyan = Color(0xFF00E5FF)
val MoonGlow = Color(0xFF80D8FF)
val NinjaGold = Color(0xFFFFD54F)
val JadeGreen = Color(0xFF00E676)
val TextLight = Color(0xFFECEFF1)
val TextMuted = Color(0xFF90A4AE)
val BloodOrange = Color(0xFFFF6D00)
