package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NinjaDarkColorScheme = darkColorScheme(
    primary = Crimson,
    onPrimary = Color.White,
    primaryContainer = ShadowRed,
    onPrimaryContainer = Color.White,
    secondary = StealthCyan,
    onSecondary = Obsidian,
    secondaryContainer = DarkCard,
    onSecondaryContainer = MoonGlow,
    tertiary = NinjaGold,
    background = Obsidian,
    onBackground = TextLight,
    surface = DarkSurface,
    onSurface = TextLight,
    surfaceVariant = DarkCard,
    onSurfaceVariant = TextMuted
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NinjaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
