package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.ninja.audio.SoundManager
import com.example.ninja.data.GamePreferences
import com.example.ninja.ui.DojoScreen
import com.example.ninja.ui.GameScreen
import com.example.ninja.ui.LevelSelectScreen
import com.example.ninja.ui.MainMenuScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Obsidian

sealed class Screen {
    object MainMenu : Screen()
    object LevelSelect : Screen()
    object Dojo : Screen()
    data class Game(val levelIndex: Int) : Screen()
}

class MainActivity : ComponentActivity() {

    private lateinit var soundManager: SoundManager
    private lateinit var preferences: GamePreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Enable full-screen immersive mode for gaming
        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())

        soundManager = SoundManager(this)
        preferences = GamePreferences(this)
        soundManager.isSoundEnabled = preferences.isSoundEnabled
        soundManager.isMusicEnabled = preferences.isMusicEnabled
        soundManager.isHapticsEnabled = preferences.isHapticsEnabled

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Obsidian
                ) {
                    var currentScreen by remember { mutableStateOf<Screen>(Screen.MainMenu) }

                    when (val screen = currentScreen) {
                        is Screen.MainMenu -> {
                            MainMenuScreen(
                                preferences = preferences,
                                soundManager = soundManager,
                                onStartGame = { lvl ->
                                    currentScreen = Screen.Game(lvl)
                                },
                                onOpenLevelSelect = {
                                    currentScreen = Screen.LevelSelect
                                },
                                onOpenDojo = {
                                    currentScreen = Screen.Dojo
                                }
                            )
                        }

                        is Screen.LevelSelect -> {
                            LevelSelectScreen(
                                preferences = preferences,
                                soundManager = soundManager,
                                onSelectLevel = { lvl ->
                                    currentScreen = Screen.Game(lvl)
                                },
                                onBack = {
                                    currentScreen = Screen.MainMenu
                                }
                            )
                        }

                        is Screen.Dojo -> {
                            DojoScreen(
                                preferences = preferences,
                                soundManager = soundManager,
                                onBack = {
                                    currentScreen = Screen.MainMenu
                                }
                            )
                        }

                        is Screen.Game -> {
                            GameScreen(
                                levelIndex = screen.levelIndex,
                                preferences = preferences,
                                soundManager = soundManager,
                                onBackToMenu = {
                                    currentScreen = Screen.MainMenu
                                },
                                onNextLevel = {
                                    if (screen.levelIndex < 4) {
                                        currentScreen = Screen.Game(screen.levelIndex + 1)
                                    } else {
                                        currentScreen = Screen.MainMenu
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::soundManager.isInitialized && preferences.isMusicEnabled) {
            soundManager.startMusic()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::soundManager.isInitialized) {
            soundManager.stopMusic()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::soundManager.isInitialized) {
            soundManager.stopMusic()
        }
    }
}
